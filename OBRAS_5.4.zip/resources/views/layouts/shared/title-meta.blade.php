<meta charset="utf-8">
<title>{{ $title ?? '' }} | Obras</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="App Web desarrollo Obras" name="description">
<meta content="Alminares.es" name="author">

<!-- App favicon -->
<link rel="shortcut icon" href="/images/favicon.ico">
