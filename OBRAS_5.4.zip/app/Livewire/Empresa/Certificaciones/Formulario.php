<?php

namespace App\Livewire\Empresa\Certificaciones;

use Livewire\Component;
use Livewire\WithFileUploads;
use App\Models\Certificacion;
use App\Models\ObraGastoCategoria;
use App\Models\Cliente;

class Formulario extends Component
{
    use WithFileUploads;

    public $obraId;

    public $cliente_id;
    public $obra_gasto_categoria_id;

    public $fecha_ingreso;
    public $fecha_contable;

    public $iva_porcentaje = 21;
    public $retencion_porcentaje = 0;

    public $numero_certificacion;
    public $adjunto;

    public function mount($obraId)
    {
        $this->obraId = $obraId;
    }

    protected $rules = [
        'cliente_id'               => 'required|exists:clientes,id',
        'obra_gasto_categoria_id'  => 'required|exists:obra_gasto_categorias,id',

        'fecha_ingreso'      => 'required|date',
        'fecha_contable'           => 'nullable|date',

        'iva_porcentaje'          => 'nullable|numeric|min:0',
        'retencion_porcentaje'    => 'nullable|numeric|min:0',

        'numero_certificacion'     => 'nullable|string|max:255',
        'adjunto'                  => 'nullable|file|max:4096',
    ];

    public function guardar()
    {

        $this->validate();

        $adjuntoUrl = $this->adjunto
            ? $this->adjunto->store('certificaciones', 'public')
            : null;

        Certificacion::create([
            'obra_id'                 => $this->obraId,
            'cliente_id'              => $this->cliente_id,
            'obra_gasto_categoria_id' => $this->obra_gasto_categoria_id,

            'fecha_ingreso'     => $this->fecha_ingreso,
            'fecha_contable'          => $this->fecha_contable,

            'numero_certificacion'    => $this->numero_certificacion,

            // Importes iniciales (se recalculan luego)
            'base_imponible'          => 0,
            'iva_porcentaje'          => $this->iva_porcentaje,
            'iva_importe'             => 0,
            'retencion_porcentaje'    => $this->retencion_porcentaje,
            'retencion_importe'       => 0,
            'total'                   => 0,

            // Estados
            'estado_certificacion'    => 'enviada',
            'estado_factura'          => null,

            'adjunto_url'             => $adjuntoUrl,
        ]);

        $this->dispatch('toast', type: 'success', text: 'Certificación creada. Añade ahora los conceptos.');
        $this->dispatch('cerrarModal');

        // Reset selectivo (NO tocamos $clientes)
        $this->reset([
            'cliente_id',
            'obra_gasto_categoria_id',
            'fecha_ingreso',
            'fecha_contable',
            'iva_porcentaje',
            'retencion_porcentaje',
            'numero_certificacion',
            'adjunto',
        ]);
    }

    public function render()
    {
        return view('livewire.empresa.certificaciones.formulario', [
            'oficios' => ObraGastoCategoria::where('obra_id', $this->obraId)
                ->orderBy('nombre')
                ->get(),

            'clientes' => Cliente::orderBy('nombre')->get(),
        ]);
    }
}
