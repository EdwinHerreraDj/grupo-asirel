<?php

namespace App\Livewire\Empresa\Certificaciones;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\ObraGastoCategoria;
use App\Models\Certificacion;
use App\Models\Cliente;
use Illuminate\Support\Facades\Storage;


class Index extends Component
{
    use WithPagination;

    public $obraId;

    public $showModal = false;
    public $showDeleteModal = false;
    public $certificacionAEliminar = null;

    // Filtros

    // PENDING (usuario escribe)
    public $pendingOficio = '';
    public $pendingTipo = '';
    public $pendingFechaDesde = '';
    public $pendingFechaHasta = '';
    public $pendingSearch = '';

    // FILTROS REALES (se aplican solo al pulsar el botón)
    public $filtroOficio = '';
    public $filtroTipo = '';
    public $fechaDesde = '';
    public $fechaHasta = '';
    public $search = '';

    // PENDING
    public $pendingCliente = '';
    public $pendingEstadoCertificacion = '';

    // FILTROS APLICADOS
    public $filtroCliente = '';
    public $estadoCertificacion = '';



    protected $paginationTheme = 'tailwind';

    protected $listeners = [
        'cerrarModal' => 'cerrarModal',
    ];

    public function mount($obraId)
    {
        $this->obraId = $obraId;
    }

    public function abrirModal()
    {
        $this->showModal = true;
    }

    public function cerrarModal()
    {
        $this->showModal = false;
        $this->dispatch('$refresh');
    }

    public function confirmarEliminar($id)
    {
        $this->certificacionAEliminar = $id;
        $this->showDeleteModal = true;
    }

    public function eliminar()
    {
        $cert = Certificacion::find($this->certificacionAEliminar);

        if ($cert) {
            if ($cert->adjunto_url && Storage::disk('public')->exists($cert->adjunto_url)) {
                Storage::disk('public')->delete($cert->adjunto_url);
            }
            $cert->delete();
        }

        $this->showDeleteModal = false;
        $this->certificacionAEliminar = null;

        $this->dispatch('toast', type: 'success', text: 'Certificación eliminada correctamente.');
    }

    public function aplicarFiltros()
    {
        $this->filtroOficio = $this->pendingOficio;
        $this->filtroCliente = $this->pendingCliente;
        $this->estadoCertificacion = $this->pendingEstadoCertificacion;

        $this->fechaDesde = $this->pendingFechaDesde;
        $this->fechaHasta = $this->pendingFechaHasta;
        $this->search = $this->pendingSearch;

        $this->resetPage();
    }


    public function limpiarFiltros()
    {
        $this->pendingOficio = '';
        $this->pendingCliente = '';
        $this->pendingEstadoCertificacion = '';
        $this->pendingFechaDesde = '';
        $this->pendingFechaHasta = '';
        $this->pendingSearch = '';

        $this->filtroOficio = '';
        $this->filtroCliente = '';
        $this->estadoCertificacion = '';
        $this->fechaDesde = '';
        $this->fechaHasta = '';
        $this->search = '';

        $this->resetPage();
    }

    public function verCertificacionDetalles($certificacionId)
    {
        return redirect()->route('empresa.certificaciones.show', ['certificacion' => $certificacionId]);
    }



    public function render()
    {
        $query = Certificacion::where('obra_id', $this->obraId)
            ->with(['oficio', 'cliente']);

        // BUSCADOR (solo campos válidos)
        if ($this->search) {
            $query->where('numero_certificacion', 'like', "%{$this->search}%");
        }

        // FILTRO OFICIO
        if ($this->filtroOficio) {
            $query->where('obra_gasto_categoria_id', $this->filtroOficio);
        }

        // FILTRO CLIENTE
        if ($this->filtroCliente) {
            $query->where('cliente_id', $this->filtroCliente);
        }

        // ESTADO CERTIFICACIÓN
        if ($this->estadoCertificacion) {
            $query->where('estado_certificacion', $this->estadoCertificacion);
        }

        // FECHAS (fecha_certificacion)
        if ($this->fechaDesde) {
            $query->whereDate('fecha_certificacion', '>=', $this->fechaDesde);
        }

        if ($this->fechaHasta) {
            $query->whereDate('fecha_certificacion', '<=', $this->fechaHasta);
        }

        return view('livewire.empresa.certificaciones.index', [
            'certificaciones' => $query
                ->orderBy('fecha_certificacion', 'desc')
                ->paginate(10),

            'oficios' => ObraGastoCategoria::where('obra_id', $this->obraId)
                ->orderBy('nombre')
                ->get(),

            // NECESARIO para el filtro
            'clientes' => Cliente::orderBy('nombre')->get(),
        ]);
    }
}
