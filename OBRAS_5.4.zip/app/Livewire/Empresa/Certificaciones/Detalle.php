<?php

namespace App\Livewire\Empresa\Certificaciones;

use App\Models\Certificacion;
use App\Models\CertificacionDetalle;
use App\Services\CertificacionCalculator;
use Livewire\Component;

class Detalle extends Component
{
    public ?Certificacion $certificacion = null;

    public $showModal = false;
    public $modoEdicion = false;
    public $detalleId = null;

    // Campos del formulario
    public $concepto = '';
    public $unidad = '';
    public $cantidad = 1;
    public $precio_unitario = 0;

    public $showDeleteModal = false;
    public $detalleAEliminarId = null;

    public $showAceptarModal = false;

    // pending (inputs)
    public $pendingSearch = '';
    public $pendingUnidad = '';
    public $pendingImporteMin = '';
    public $pendingImporteMax = '';

    // filtros aplicados
    public $search = '';
    public $filtroUnidad = '';
    public $importeMin = '';
    public $importeMax = '';


    public $showImpuestosModal = false;

    public $iva_porcentaje = 21;
    public $retencion_porcentaje = 0;




    protected $casts = [
        'cantidad' => 'float',
        'precio_unitario' => 'float',
    ];

    protected $rules = [
        'concepto'        => 'required|string|max:255',
        'unidad'          => 'required|string|max:100',
        'cantidad'        => 'required|numeric|min:0',
        'precio_unitario' => 'required|numeric|min:0',
    ];


    public function mount($certificacionId)
    {
        $this->certificacion = Certificacion::with([
            'cliente',
            'oficio',
            'detalles'
        ])->findOrFail($certificacionId);
    }

    public function abrirModalCrear()
    {
        if ($this->certificacion->estado_certificacion !== 'enviada') {
            return;
        }

        $this->resetFormulario();

        $this->modoEdicion = false;
        $this->showModal = true;
    }

    public function abrirModalEditar($detalleId)
    {
        if ($this->certificacion->estado_certificacion !== 'enviada') {
            return;
        }

        $detalle = CertificacionDetalle::findOrFail($detalleId);

        $this->detalleId = $detalle->id;
        $this->concepto = $detalle->concepto;
        $this->unidad = $detalle->unidad;
        $this->cantidad = $detalle->cantidad;
        $this->precio_unitario = $detalle->precio_unitario;

        $this->modoEdicion = true;
        $this->showModal = true;
    }

    public function abrirModalImpuestos()
    {
        if ($this->certificacion->estado_certificacion !== 'enviada') {
            return;
        }

        $this->iva_porcentaje = $this->certificacion->iva_porcentaje;
        $this->retencion_porcentaje = $this->certificacion->retencion_porcentaje;

        $this->showImpuestosModal = true;
    }


    public function confirmarEliminarDetalle($detalleId)
    {
        if ($this->certificacion->estado_certificacion !== 'enviada') {
            return;
        }

        $this->detalleAEliminarId = $detalleId;
        $this->showDeleteModal = true;
    }

    public function eliminarDetalle()
    {
        if ($this->certificacion->estado_certificacion !== 'enviada') {
            return;
        }

        $detalle = CertificacionDetalle::find($this->detalleAEliminarId);

        if ($detalle) {
            $detalle->delete();
        }

        app(CertificacionCalculator::class)
            ->recalcular($this->certificacion->fresh());

        $this->certificacion = $this->certificacion->fresh([
            'cliente',
            'oficio',
            'detalles'
        ]);

        $this->detalleAEliminarId = null;
        $this->showDeleteModal = false;

        $this->dispatch('toast', type: 'success', text: 'Detalle eliminado correctamente.');
    }


    public function confirmarAceptar()
    {
        if ($this->certificacion->estado_certificacion !== 'enviada') {
            return;
        }

        $this->showAceptarModal = true;
    }

    public function aceptarCertificacion()
    {
        if ($this->certificacion->estado_certificacion !== 'enviada') {
            return;
        }

        $this->certificacion->update([
            'estado_certificacion' => 'aceptada',
        ]);

        $this->certificacion->refresh();

        $this->showAceptarModal = false;

        $this->dispatch(
            'toast',
            type: 'success',
            text: 'Certificación aceptada correctamente. Ya no se puede modificar.'
        );
    }

    public function guardarImpuestos()
    {
        if ($this->certificacion->estado_certificacion !== 'enviada') {
            return;
        }

        $this->validate([
            'iva_porcentaje' => 'required|numeric|min:0',
            'retencion_porcentaje' => 'required|numeric|min:0',
        ]);

        $this->certificacion->update([
            'iva_porcentaje' => (float) $this->iva_porcentaje,
            'retencion_porcentaje' => (float) $this->retencion_porcentaje,
        ]);

        app(CertificacionCalculator::class)
            ->recalcular($this->certificacion->fresh());

        $this->certificacion = $this->certificacion->fresh([
            'cliente',
            'oficio',
            'detalles'
        ]);

        $this->showImpuestosModal = false;

        $this->dispatch(
            'toast',
            type: 'success',
            text: 'Impuestos actualizados correctamente.'
        );
    }



    public function guardarDetalle()
    {
        if ($this->certificacion->estado_certificacion !== 'enviada') {
            return;
        }

        $this->validate();

        $cantidad = (float) $this->cantidad;
        $precio   = (float) $this->precio_unitario;
        $importe  = $cantidad * $precio;

        if ($this->modoEdicion) {
            $detalle = CertificacionDetalle::findOrFail($this->detalleId);

            $detalle->update([
                'concepto'        => $this->concepto,
                'unidad'          => $this->unidad,
                'cantidad'        => $cantidad,
                'precio_unitario' => $precio,
                'importe_linea'   => $importe,
            ]);
        } else {
            CertificacionDetalle::create([
                'certificacion_id' => $this->certificacion->id,
                'concepto'         => $this->concepto,
                'unidad'           => $this->unidad,
                'cantidad'         => $cantidad,
                'precio_unitario'  => $precio,
                'importe_linea'    => $importe,
            ]);
        }

        // REGLA CLAVE: recalcular + refrescar el modelo COMPLETO
        app(CertificacionCalculator::class)
            ->recalcular($this->certificacion->fresh());

        $this->certificacion = $this->certificacion->fresh([
            'cliente',
            'oficio',
            'detalles'
        ]);

        $this->cerrarModal();

        $this->dispatch(
            'toast',
            type: 'success',
            text: $this->modoEdicion
                ? 'Detalle actualizado correctamente.'
                : 'Detalle añadido correctamente.'
        );
    }



    private function resetFormulario()
    {
        $this->detalleId = null;
        $this->concepto = '';
        $this->unidad = '';
        $this->cantidad = 1;
        $this->precio_unitario = 0;
    }

    public function cerrarModal()
    {
        $this->resetFormulario();
        $this->modoEdicion = false;
        $this->showModal = false;
    }

    public function aplicarFiltros()
    {
        $this->search       = $this->pendingSearch;
        $this->filtroUnidad = $this->pendingUnidad;
        $this->importeMin   = $this->pendingImporteMin;
        $this->importeMax   = $this->pendingImporteMax;
    }

    public function limpiarFiltros()
    {
        $this->pendingSearch = '';
        $this->pendingUnidad = '';
        $this->pendingImporteMin = '';
        $this->pendingImporteMax = '';

        $this->search = '';
        $this->filtroUnidad = '';
        $this->importeMin = '';
        $this->importeMax = '';
    }


    public function getDetallesFiltradosProperty()
    {
        $detalles = $this->certificacion->detalles;

        if ($this->search) {
            $detalles = $detalles->filter(
                fn($d) =>
                str_contains(
                    mb_strtolower($d->concepto),
                    mb_strtolower($this->search)
                )
            );
        }

        if ($this->filtroUnidad) {
            $detalles = $detalles->where('unidad', $this->filtroUnidad);
        }

        if ($this->importeMin !== '') {
            $detalles = $detalles->where('importe_linea', '>=', (float) $this->importeMin);
        }

        if ($this->importeMax !== '') {
            $detalles = $detalles->where('importe_linea', '<=', (float) $this->importeMax);
        }

        return $detalles;
    }



    public function render()
    {
        return view('livewire.empresa.certificaciones.detalle');
    }
}
