php artisan config:clear
php artisan route:clear
php artisan cache:clear
php artisan view:clear



php artisan make:model Subcontrata -m <!-- Comando para crear el modelo y la respectiva migracion -->
php artisan make:controller NombreController --resource <!-- Comando para crear un controlador -->

php artisan route:list <!-- Listar las rutas -->



