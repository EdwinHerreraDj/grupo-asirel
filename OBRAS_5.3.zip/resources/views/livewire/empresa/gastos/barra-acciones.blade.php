<div>
    <a href="{{ route('empresa.index') }}"
        class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-700 font-medium shadow-sm border border-gray-200 
               hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-primary/30 mb-7">
        <i class="mgc_arrow_left_line text-lg"></i>
        Regresar
    </a>
    <hr class="mb-3">
    <div class="flex flex-wrap items-center justify-between gap-3 mb-6">

        <div class="flex flex-wrap items-center gap-3">
            {{-- Botón: Nuevo gasto --}}
            <button wire:click="abrirFormularioGasto"
                class="inline-flex items-center gap-2 px-4 py-2 rounded-full 
                   bg-green-500/15 text-green-700 font-medium border border-green-500/30 
                   shadow-sm hover:bg-green-600 hover:text-white 
                   active:scale-[0.97] transition-all duration-300 
                   focus:outline-none focus:ring-2 focus:ring-green-400/40">
                <i class="mgc_add_line text-lg"></i>
                Nuevo gasto
            </button>

            {{-- Botón: Nueva categoría --}}
            <button wire:click="abrirModalCategoria"
                class="inline-flex items-center gap-2 px-4 py-2 rounded-full 
                   bg-cyan-500/15 text-cyan-700 font-medium border border-cyan-500/30 
                   shadow-sm hover:bg-cyan-600 hover:text-white 
                   active:scale-[0.97] transition-all duration-300 
                   focus:outline-none focus:ring-2 focus:ring-cyan-400/40">
                <i class="mgc_black_board_2_line text-lg"></i>
                Nueva categoría
            </button>
        </div>

        {{-- Botón: Descargar informe --}}
        <button wire:click="$dispatchTo('empresa.gastos.gastos-empresa', 'abrirExportModal')"
            class="inline-flex items-center gap-2 px-4 py-2 rounded-full 
               bg-emerald-600 text-white font-medium border border-emerald-700/30 
               shadow-sm hover:bg-emerald-700 
               active:scale-[0.97] transition-all duration-300 
               focus:outline-none focus:ring-2 focus:ring-emerald-400/40">
            <i class="mgc_download_2_line text-lg"></i>
            Descargar informe
        </button>

    </div>
</div>
