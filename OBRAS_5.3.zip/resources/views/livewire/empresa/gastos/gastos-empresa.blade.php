<div class="space-y-6">

    {{-- Formulario de nuevo gasto --}}
    @if ($showForm)
        <div
            class="relative p-6 border border-blue-200 dark:border-blue-900/40 rounded-2xl shadow-md 
           bg-white dark:bg-gray-800 animate-fadeIn overflow-hidden transition-all duration-300">

            {{-- Línea lateral decorativa --}}
            <div class="absolute left-0 top-0 h-full w-1 bg-blue-500/80 rounded-l-2xl"></div>

            {{-- Encabezado --}}
            <div class="flex items-center gap-3 mb-6">
                <div
                    class="flex items-center justify-center w-10 h-10 rounded-xl 
                   bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300">
                    <i class="mgc_currency_euro_line text-xl"></i>
                </div>
                <div>
                    <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-100">Registrar nuevo gasto</h3>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Completa la información del gasto y adjunta la
                        factura si es necesario.</p>
                </div>
            </div>

            {{-- Formulario --}}
            <form wire:submit.prevent="guardar" class="grid grid-cols-1 md:grid-cols-2 gap-5">

                {{-- Concepto --}}
                <div>
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Concepto <span
                            class="text-red-500">*</span></label>
                    <input wire:model.defer="concepto" type="text"
                        class="w-full mt-1 px-3.5 py-2 rounded-md border border-gray-300 dark:border-gray-600 
                       dark:bg-gray-900 dark:text-gray-100 placeholder-gray-400 focus:ring-1 
                       focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                        placeholder="Ej. Factura de luz octubre">
                    @error('concepto')
                        <p class="text-red-500 text-xs mt-1 flex items-center gap-1.5">
                            <i class="mgc_warning_line text-sm"></i> {{ $message }}
                        </p>
                    @enderror
                </div>

                {{-- Importe --}}
                <div>
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Importe (€) <span
                            class="text-red-500">*</span></label>
                    <input wire:model.defer="importe" type="number" step="0.01"
                        class="w-full mt-1 px-3.5 py-2 rounded-md border border-gray-300 dark:border-gray-600 
                       dark:bg-gray-900 dark:text-gray-100 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all"
                        placeholder="0.00">
                    @error('importe')
                        <p class="text-red-500 text-xs mt-1 flex items-center gap-1.5">
                            <i class="mgc_warning_line text-sm"></i> {{ $message }}
                        </p>
                    @enderror
                </div>

                {{-- Fecha --}}
                <div>
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Fecha del gasto <span
                            class="text-red-500">*</span></label>
                    <input wire:model.defer="fecha_gasto" type="date"
                        class="w-full mt-1 px-3.5 py-2 rounded-md border border-gray-300 dark:border-gray-600 
                       dark:bg-gray-900 dark:text-gray-100 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all">
                    @error('fecha_gasto')
                        <p class="text-red-500 text-xs mt-1 flex items-center gap-1.5">
                            <i class="mgc_warning_line text-sm"></i> {{ $message }}
                        </p>
                    @enderror
                </div>

                {{-- Categoría --}}
                <div>
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Categoría <span
                            class="text-red-500">*</span></label>
                    <select wire:model.defer="categoria_id"
                        class="w-full mt-1 px-3.5 py-2 rounded-md border border-gray-300 dark:border-gray-600 
                       dark:bg-gray-900 dark:text-gray-100 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all">
                        <option value="">Seleccionar categoría...</option>
                        @foreach ($categorias as $cat)
                            <option value="{{ $cat->id }}">{{ $cat->nombre }}</option>
                        @endforeach
                    </select>
                    @error('categoria_id')
                        <p class="text-red-500 text-xs mt-1 flex items-center gap-1.5">
                            <i class="mgc_warning_line text-sm"></i> {{ $message }}
                        </p>
                    @enderror
                </div>

                {{-- Descripción --}}
                <div class="md:col-span-2">
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Descripción</label>
                    <textarea wire:model.defer="descripcion" rows="2"
                        class="w-full mt-1 px-3.5 py-2 rounded-md border border-gray-300 dark:border-gray-600 
                       dark:bg-gray-900 dark:text-gray-100 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all"></textarea>
                </div>

                {{-- Factura --}}
                <div class="md:col-span-2">
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Factura (opcional)</label>

                    {{-- Input clásico con estilo --}}
                    <input wire:model="factura" type="file"
                        class="w-full mt-1 text-sm rounded-md cursor-pointer border border-gray-300 dark:border-gray-600
                       file:mr-4 file:py-2 file:px-4 file:rounded-l-md
                       file:border-0 file:bg-blue-600 file:text-white 
                       hover:file:bg-blue-700 focus:outline-none focus:ring-1 focus:ring-blue-500
                       text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-900 transition-all duration-200">

                    {{-- Barra de carga Livewire --}}
                    <div wire:loading wire:target="factura" class="mt-3">
                        <div class="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                            <div class="h-2 bg-blue-600 animate-pulse w-2/3 rounded-full"></div>
                        </div>
                        <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Cargando factura...</p>
                    </div>

                    {{-- Nombre del archivo cargado --}}
                    @if ($factura)
                        <div class="mt-3 text-sm text-green-700 dark:text-green-400 flex items-center gap-2">
                            <i class="mgc_file_check_line text-base"></i>
                            <span>Factura seleccionada: <strong>{{ $factura->getClientOriginalName() }}</strong></span>
                        </div>
                    @endif

                    @error('factura')
                        <p class="text-red-500 text-xs mt-2 flex items-center gap-1.5">
                            <i class="mgc_warning_line text-sm"></i> {{ $message }}
                        </p>
                    @enderror
                </div>

                {{-- Botones --}}
                <div class="md:col-span-2 flex justify-end gap-3 mt-6">
                    <button type="button" wire:click="$set('showForm', false)"
                        class="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-gray-300 dark:border-gray-600 
                       text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 
                       active:scale-[0.97] transition-all duration-200 focus:outline-none focus:ring-1 focus:ring-gray-400">
                        <i class="mgc_close_fill text-base"></i> Cancelar
                    </button>

                    <button type="submit"
                        class="inline-flex items-center gap-2 px-4 py-2 rounded-full 
                       bg-blue-600 text-white hover:bg-blue-700 active:scale-[0.97] 
                       focus:outline-none focus:ring-2 focus:ring-blue-300 transition-all duration-200">
                        <i class="mgc_check_fill text-base"></i> Guardar gasto
                    </button>
                </div>
            </form>
        </div>

    @endif

    {{-- Tabla de gastos --}}
    <div wire:ignore
        class="overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-700 p-4 shadow-sm bg-white dark:bg-gray-800">
        <table id="table-docs">
            <thead>
                <tr>
                    <th>Concepto</th>
                    <th>Categoría</th>
                    <th>Fecha</th>
                    <th>Importe (€)</th>
                    <th>Factura</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($gastos as $gasto)
                    <tr>
                        <td>{{ $gasto->concepto }}</td>
                        <td>{{ $gasto->categoria->nombre }}</td>
                        <td>{{ \Carbon\Carbon::parse($gasto->fecha_gasto)->format('d/m/Y') }}</td>
                        <td>{{ number_format($gasto->importe, 2, ',', '.') }}</td>
                        <td>
                            @if ($gasto->factura_url)
                                <button wire:click="verFactura('{{ Storage::url($gasto->factura_url) }}')"
                                    class="open-pdf-modal inline-flex items-center justify-center w-9 h-9 rounded-full 
                                    bg-blue-100 text-blue-700 border border-blue-200 
                                    hover:bg-blue-200 hover:border-blue-300 transition-all duration-200 shadow-sm">
                                    <i class="mgc_eye_line text-base"></i>
                                </button>
                            @else
                                <span>—</span>
                            @endif
                        </td>
                        <td>
                            <x-btns.eliminar wire:click="eliminar({{ $gasto->id }})" />
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    {{-- Modal visor de factura --}}
    @if ($showModal)
        <div class="fixed inset-0 z-[70] flex items-center justify-center overflow-hidden" aria-modal="true"
            role="dialog" wire:ignore.self>

            {{-- 🔲 Fondo oscuro que cubre TODO el viewport (sin líneas) --}}
            <div class="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity z-40" wire:click="cerrarVisor">
            </div>

            {{-- Contenedor del modal --}}
            <div
                class="relative w-full max-w-5xl mx-4 rounded-2xl border border-gray-200 dark:border-gray-700
                   bg-white dark:bg-gray-800 shadow-2xl animate-[fadeIn_.15s_ease-out]
                   flex flex-col overflow-hidden h-[95vh] max-h-[95vh] z-50">

                {{-- 🔹 Header --}}
                <div
                    class="flex items-center justify-between bg-gray-100 dark:bg-gray-800 px-4 py-2
                       border-b border-gray-200 dark:border-gray-700">
                    <div class="flex items-center gap-2 text-gray-700 dark:text-gray-200">
                        <i class="mgc_file_line text-blue-600 text-xl"></i>
                        <span class="text-sm font-medium truncate max-w-[250px]">{{ $archivoNombre }}</span>
                    </div>
                    <button wire:click="cerrarVisor"
                        class="text-gray-500 hover:text-red-500 text-xl font-bold transition-all duration-200">
                        &times;
                    </button>
                </div>

                {{-- Contenido principal (PDF / Imagen / Mensaje) --}}
                <div class="flex-1 bg-gray-50 dark:bg-gray-950 relative">

                    {{-- Loader mientras se carga --}}
                    <div wire:loading.flex
                        class="absolute inset-0 bg-white/80 dark:bg-gray-900/80 
                            items-center justify-center z-50">
                        <div class="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent">
                        </div>
                    </div>

                    @if ($archivoUrl)
                        @php
                            $ext = strtolower(pathinfo($archivoUrl, PATHINFO_EXTENSION));
                        @endphp

                        {{-- Mostrar PDF --}}
                        @if ($ext === 'pdf')
                            <iframe src="{{ $archivoUrl }}#view=FitH" class="w-full h-full rounded-b-xl"
                                frameborder="0"></iframe>

                            {{-- Mostrar imagen --}}
                        @elseif (in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp']))
                            <img src="{{ $archivoUrl }}"
                                class="object-contain w-full h-full bg-gray-100 rounded-b-xl">

                            {{-- Formato no compatible --}}
                        @else
                            <div class="flex items-center justify-center h-full text-gray-500">
                                Formato no compatible para vista previa
                            </div>
                        @endif
                    @endif
                </div>
            </div>
        </div>
    @endif

    {{-- Modal para generar el informe --}}
    @if ($showExportModal)
    <div class="fixed inset-0 z-[70] flex items-center justify-center overflow-hidden" aria-modal="true"
        role="dialog" wire:ignore.self>

        {{-- Fondo oscuro --}}
        <div class="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
            wire:click="cerrarExportModal"></div>

        {{-- Contenedor principal --}}
        <div
            class="relative w-full max-w-md mx-4 rounded-2xl border border-gray-200 dark:border-gray-700
                   bg-white dark:bg-gray-800 shadow-2xl animate-[fadeIn_.15s_ease-out]
                   overflow-hidden z-50">

            {{-- Header --}}
            <div class="flex items-center gap-4 p-5 border-b border-gray-100 dark:border-gray-700">
                <div
                    class="w-12 h-12 flex items-center justify-center rounded-xl 
                           bg-blue-100 text-blue-600 dark:bg-blue-900/40 dark:text-blue-300">
                    <i class="mgc_download_2_line text-2xl"></i>
                </div>
                <div>
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Descargar informe</h3>
                    <p class="text-sm text-gray-600 dark:text-gray-400">
                        Selecciona un rango de fechas y el formato del archivo.
                    </p>
                </div>
            </div>

            {{-- Contenido --}}
            <div class="p-6 space-y-5">
                {{-- Fechas --}}
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label
                            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Desde</label>
                        <input type="date" wire:model="fechaInicio"
                            class="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600
                                   bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-200 
                                   focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                    </div>
                    <div>
                        <label
                            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Hasta</label>
                        <input type="date" wire:model="fechaFin"
                            class="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600
                                   bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-200 
                                   focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                    </div>
                </div>

                {{-- Botones --}}
                <div class="flex flex-col sm:flex-row justify-end gap-3 pt-2">
                    {{-- Cancelar --}}
                    <button wire:click="cerrarExportModal"
                        class="px-4 py-2 rounded-lg border border-gray-300 text-gray-700 
                               hover:bg-gray-50 dark:border-gray-600 dark:text-gray-200 dark:hover:bg-gray-700
                               transition-all duration-200 active:scale-[0.97]">
                        Cancelar
                    </button>

                    {{-- PDF --}}
                    <button wire:click="descargarPDF"
                        class="px-4 py-2 rounded-lg bg-red-600 text-white flex items-center gap-2 
                               shadow-sm hover:bg-red-700 focus:ring-2 focus:ring-red-400/50 
                               transition-all duration-200 active:scale-[0.97]">
                        <i class="mgc_pdf_line text-lg"></i>
                        PDF
                    </button>

                    {{-- Excel --}}
                    <button wire:click="descargarExcel"
                        class="px-4 py-2 rounded-lg bg-green-600 text-white flex items-center gap-2 
                               shadow-sm hover:bg-green-700 focus:ring-2 focus:ring-green-400/50 
                               transition-all duration-200 active:scale-[0.97]">
                        <i class="mgc_xls_line text-lg"></i>
                        Excel
                    </button>
                </div>
            </div>
        </div>
    </div>
    @endif

</div>
