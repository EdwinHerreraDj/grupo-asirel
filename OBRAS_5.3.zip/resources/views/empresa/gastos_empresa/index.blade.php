@extends('layouts.vertical', ['title' => 'Gastos empresa', 'sub_title' => 'Pages', 'mode' => $mode ?? '', 'demo' => $demo ?? ''])

@section('content')
    <div class="grid grid-cols-12">
        <div class="col-span-12 card p-10">

            {{-- Barra de acciones --}}
            <livewire:empresa.gastos.barra-acciones />

            <livewire:empresa.gastos.categorias-gasto-empresa />
            <livewire:empresa.gastos.gastos-empresa />
        </div>
    </div>


@endsection
