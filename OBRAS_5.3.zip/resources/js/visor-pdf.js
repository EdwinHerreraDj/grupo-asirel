document.addEventListener('DOMContentLoaded', () => {

    const modal = document.getElementById('pdfModal');
    const pdfViewer = document.getElementById('pdfViewer');
    const closeBtn = document.getElementById('closePdfModal');

    document.querySelectorAll('.open-pdf-modal').forEach(button => {
        button.addEventListener('click', () => {
            const pdfUrl = button.getAttribute('data-pdf');
            pdfViewer.src = pdfUrl;
            modal.classList.remove('hidden');
        });
    });

    closeBtn.addEventListener('click', () => {
        modal.classList.add('hidden');
        pdfViewer.src = '';
    });


    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.classList.add('hidden');
            pdfViewer.src = '';
        }
    });
});
