<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CategoriaGastoEmpresa extends Model
{
    protected $table = 'categorias_gastos_empresa';

    protected $fillable = ['nombre', 'descripcion'];

    public function gastos()
    {
        return $this->hasMany(GastoGeneralEmpresa::class, 'categoria_id');
    }
}
