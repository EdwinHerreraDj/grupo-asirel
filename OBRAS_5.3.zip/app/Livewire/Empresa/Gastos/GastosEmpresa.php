<?php

namespace App\Livewire\Empresa\Gastos;

use App\Models\GastoGeneralEmpresa;
use App\Models\CategoriaGastoEmpresa;
use Livewire\Component;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\On;

class GastosEmpresa extends Component
{
    use WithFileUploads;

    public $concepto = '';
    public $importe = '';
    public $fecha_gasto = '';
    public $descripcion = '';
    public $factura;
    public $categoria_id = '';
    public $showForm = false;
    public $search = '';
    public $filtro = '';

    public $gastos;
    public $categorias;

    public bool $showModal = false;
    public ?string $archivoUrl = null;
    public ?string $archivoNombre = null;
    public bool $showExportModal = false;
    public string $exportFormat = 'pdf';
    public ?string $fechaInicio = null;
    public ?string $fechaFin = null;


    protected $rules = [
        'concepto' => 'required|string|max:255',
        'importe' => 'required|numeric|min:0',
        'fecha_gasto' => 'required|date',
        'descripcion' => 'nullable|string|max:255',
        'categoria_id' => 'required|exists:categorias_gastos_empresa,id',
        'factura' => 'nullable|file|mimes:pdf,jpg,png|max:5120',
    ];

    public function mount()
    {
        $this->loadData();
    }

    public function verFactura(string $url)
    {
        $this->archivoUrl = $url;
        $this->archivoNombre = basename($url);
        $this->showModal = true;
    }

    public function cerrarVisor()
    {
        $this->reset(['showModal', 'archivoUrl', 'archivoNombre']);
    }

    #[On('abrirExportModal')]
    public function abrirExportModal()
    {
        $this->reset(['exportFormat', 'fechaInicio', 'fechaFin']);
        $this->exportFormat = 'pdf';
        $this->showExportModal = true;
    }

    public function cerrarExportModal()
    {
        $this->reset(['showExportModal', 'exportFormat', 'fechaInicio', 'fechaFin']);
    }

    public function descargarPDF()
    {
        $this->validate([
            'fechaInicio' => 'nullable|date',
            'fechaFin' => 'nullable|date|after_or_equal:fechaInicio',
        ]);
    
        return redirect()->route('empresa.gastos.exportar.pdf', [
            'inicio' => $this->fechaInicio,
            'fin' => $this->fechaFin,
        ]);
    }
    
    public function descargarExcel()
    {
        $this->validate([
            'fechaInicio' => 'nullable|date',
            'fechaFin' => 'nullable|date|after_or_equal:fechaInicio',
        ]);
    
        return redirect()->route('empresa.gastos.exportar.excel', [
            'inicio' => $this->fechaInicio,
            'fin' => $this->fechaFin,
        ]);
    }




    #[On('categoriaCreada')]
    public function loadData()
    {
        $this->categorias = CategoriaGastoEmpresa::orderBy('nombre')->get();
        $this->gastos = GastoGeneralEmpresa::with('categoria')->latest('fecha_gasto')->get();
    }

    public function guardar()
    {
        $this->validate();

        $data = [
            'concepto' => $this->concepto,
            'importe' => $this->importe,
            'fecha_gasto' => $this->fecha_gasto,
            'descripcion' => $this->descripcion,
            'categoria_id' => $this->categoria_id,
        ];

        if ($this->factura) {
            $data['factura_url'] = $this->factura->store('facturas_empresa', 'public');
        }

        GastoGeneralEmpresa::create($data);

        $this->reset(['concepto', 'importe', 'fecha_gasto', 'descripcion', 'categoria_id', 'factura', 'showForm']);
        $this->dispatch('toast', type: 'success', text: 'Gasto registrado correctamente.');
        return redirect(request()->header('Referer'));
    }

    public function eliminar($id)
    {
        $gasto = GastoGeneralEmpresa::findOrFail($id);

        // Eliminamos la factura si existe
        if ($gasto->factura_url && Storage::disk('public')->exists($gasto->factura_url)) {
            Storage::disk('public')->delete($gasto->factura_url);
        }

        $gasto->delete();

        $this->dispatch('toast', type: 'success', text: 'Gasto eliminado correctamente.');
        return redirect(request()->header('Referer'));
    }

    #[On('abrirFormularioGasto')]
    public function abrirFormulario()
    {
        $this->showForm = true;
    }


   public function render()
    {
        $gastos = GastoGeneralEmpresa::with('categoria')
            ->when($this->filtro, function ($query) {
                $query->where('concepto', 'like', '%' . $this->filtro . '%')
                      ->orWhereHas('categoria', function ($q) {
                          $q->where('nombre', 'like', '%' . $this->filtro . '%');
                      });
            })
            ->orderByDesc('fecha_gasto')
            ->get();

        return view('livewire.empresa.gastos.gastos-empresa', compact('gastos'));
    }
}
