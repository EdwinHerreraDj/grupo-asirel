<?php

namespace App\Livewire\Empresa\Gastos;

use App\Models\CategoriaGastoEmpresa;
use Livewire\Component;
use Livewire\Attributes\On;

class CategoriasGastoEmpresa extends Component
{
    public $nombre = '';
    public $descripcion = '';
    public $showModal = false;


    public $categorias;

    protected $rules = [
        'nombre' => 'required|string|max:100|unique:categorias_gastos_empresa,nombre',
        'descripcion' => 'nullable|string|max:255',
    ];

    protected $messages = [
        'nombre.required' => 'El nombre es obligatorio.',
        'nombre.unique' => 'Ya existe una categoría con este nombre.',
    ];

    public function mount()
    {
        $this->loadCategorias();
    }

    public function loadCategorias()
    {
        $this->categorias = CategoriaGastoEmpresa::orderBy('nombre')->get();
    }

    public function abrirModal()
    {
        $this->resetValidation();
        $this->reset(['nombre', 'descripcion']);
        $this->showModal = true;
    }

    public function guardar()
    {
        $this->validate();

        CategoriaGastoEmpresa::create([
            'nombre' => $this->nombre,
            'descripcion' => $this->descripcion,
        ]);

        $this->showModal = false;
        $this->dispatch('toast', type: 'success', text: 'Categoría creada correctamente.');


        $this->dispatch('categoriaCreada');
        $this->loadCategorias();
    }

    public function eliminar($id)
    {
        $categoria = CategoriaGastoEmpresa::findOrFail($id);

        // Bloquear eliminación si tiene gastos asociados
        if ($categoria->gastos()->exists()) {
            $this->dispatch('toast', type: 'error', text: 'No puedes eliminar una categoría con gastos asociados.');
            return;
        }

        $categoria->delete();

        $this->dispatch('toast', type: 'success', text: 'Categoría eliminada correctamente.');
        $this->loadCategorias();
    }

    #[On('abrirModalCategoria')]
    public function abrirModalExterno()
    {
        $this->abrirModal(); 
    }


    public function render()
    {
        return view('livewire.empresa.gastos.categorias-gasto-empresa');
    }
}
