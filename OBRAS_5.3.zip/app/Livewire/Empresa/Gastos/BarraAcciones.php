<?php

namespace App\Livewire\Empresa\Gastos;

use Livewire\Component;

class BarraAcciones extends Component
{
    public function abrirFormularioGasto()
    {
        $this->dispatch('abrirFormularioGasto'); // Evento hacia GastosEmpresa
    }

    public function abrirModalCategoria()
    {
        $this->dispatch('abrirModalCategoria'); // Evento hacia CategoriasGastoEmpresa
    }

    public function render()
    {
        return view('livewire.empresa.gastos.barra-acciones');
    }
}
