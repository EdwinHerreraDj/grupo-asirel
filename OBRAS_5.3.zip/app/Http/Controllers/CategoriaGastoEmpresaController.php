<?php

namespace App\Http\Controllers;

use App\Models\CategoriaGastoEmpresa;
use Illuminate\Http\Request;

class CategoriaGastoEmpresaController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nombre' => 'required|string|max:100|unique:categorias_gastos_empresa,nombre',
            'descripcion' => 'nullable|string',
        ]);

        CategoriaGastoEmpresa::create($validated);

        return redirect()->back()->with('success', 'Categoría creada correctamente.');
    }
}
