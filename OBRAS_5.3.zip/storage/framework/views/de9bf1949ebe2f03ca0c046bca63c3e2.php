<div class="space-y-6">

    
    <!--[if BLOCK]><![endif]--><?php if($showForm): ?>
        <div
            class="relative p-6 border border-blue-200 dark:border-blue-900/40 rounded-2xl shadow-md 
           bg-white dark:bg-gray-800 animate-fadeIn overflow-hidden transition-all duration-300">

            
            <div class="absolute left-0 top-0 h-full w-1 bg-blue-500/80 rounded-l-2xl"></div>

            
            <div class="flex items-center gap-3 mb-6">
                <div
                    class="flex items-center justify-center w-10 h-10 rounded-xl 
                   bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300">
                    <i class="mgc_currency_euro_line text-xl"></i>
                </div>
                <div>
                    <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-100">Registrar nuevo gasto</h3>
                    <p class="text-sm text-gray-500 dark:text-gray-400">Completa la información del gasto y adjunta la
                        factura si es necesario.</p>
                </div>
            </div>

            
            <form wire:submit.prevent="guardar" class="grid grid-cols-1 md:grid-cols-2 gap-5">

                
                <div>
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Concepto <span
                            class="text-red-500">*</span></label>
                    <input wire:model.defer="concepto" type="text"
                        class="w-full mt-1 px-3.5 py-2 rounded-md border border-gray-300 dark:border-gray-600 
                       dark:bg-gray-900 dark:text-gray-100 placeholder-gray-400 focus:ring-1 
                       focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                        placeholder="Ej. Factura de luz octubre">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['concepto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1 flex items-center gap-1.5">
                            <i class="mgc_warning_line text-sm"></i> <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                
                <div>
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Importe (€) <span
                            class="text-red-500">*</span></label>
                    <input wire:model.defer="importe" type="number" step="0.01"
                        class="w-full mt-1 px-3.5 py-2 rounded-md border border-gray-300 dark:border-gray-600 
                       dark:bg-gray-900 dark:text-gray-100 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all"
                        placeholder="0.00">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['importe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1 flex items-center gap-1.5">
                            <i class="mgc_warning_line text-sm"></i> <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                
                <div>
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Fecha del gasto <span
                            class="text-red-500">*</span></label>
                    <input wire:model.defer="fecha_gasto" type="date"
                        class="w-full mt-1 px-3.5 py-2 rounded-md border border-gray-300 dark:border-gray-600 
                       dark:bg-gray-900 dark:text-gray-100 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all">
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['fecha_gasto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1 flex items-center gap-1.5">
                            <i class="mgc_warning_line text-sm"></i> <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                
                <div>
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Categoría <span
                            class="text-red-500">*</span></label>
                    <select wire:model.defer="categoria_id"
                        class="w-full mt-1 px-3.5 py-2 rounded-md border border-gray-300 dark:border-gray-600 
                       dark:bg-gray-900 dark:text-gray-100 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all">
                        <option value="">Seleccionar categoría...</option>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </select>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['categoria_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1 flex items-center gap-1.5">
                            <i class="mgc_warning_line text-sm"></i> <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                
                <div class="md:col-span-2">
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Descripción</label>
                    <textarea wire:model.defer="descripcion" rows="2"
                        class="w-full mt-1 px-3.5 py-2 rounded-md border border-gray-300 dark:border-gray-600 
                       dark:bg-gray-900 dark:text-gray-100 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all"></textarea>
                </div>

                
                <div class="md:col-span-2">
                    <label class="text-sm font-medium text-gray-700 dark:text-gray-300">Factura (opcional)</label>

                    
                    <input wire:model="factura" type="file"
                        class="w-full mt-1 text-sm rounded-md cursor-pointer border border-gray-300 dark:border-gray-600
                       file:mr-4 file:py-2 file:px-4 file:rounded-l-md
                       file:border-0 file:bg-blue-600 file:text-white 
                       hover:file:bg-blue-700 focus:outline-none focus:ring-1 focus:ring-blue-500
                       text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-900 transition-all duration-200">

                    
                    <div wire:loading wire:target="factura" class="mt-3">
                        <div class="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
                            <div class="h-2 bg-blue-600 animate-pulse w-2/3 rounded-full"></div>
                        </div>
                        <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">Cargando factura...</p>
                    </div>

                    
                    <!--[if BLOCK]><![endif]--><?php if($factura): ?>
                        <div class="mt-3 text-sm text-green-700 dark:text-green-400 flex items-center gap-2">
                            <i class="mgc_file_check_line text-base"></i>
                            <span>Factura seleccionada: <strong><?php echo e($factura->getClientOriginalName()); ?></strong></span>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['factura'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-2 flex items-center gap-1.5">
                            <i class="mgc_warning_line text-sm"></i> <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                
                <div class="md:col-span-2 flex justify-end gap-3 mt-6">
                    <button type="button" wire:click="$set('showForm', false)"
                        class="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-gray-300 dark:border-gray-600 
                       text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 
                       active:scale-[0.97] transition-all duration-200 focus:outline-none focus:ring-1 focus:ring-gray-400">
                        <i class="mgc_close_fill text-base"></i> Cancelar
                    </button>

                    <button type="submit"
                        class="inline-flex items-center gap-2 px-4 py-2 rounded-full 
                       bg-blue-600 text-white hover:bg-blue-700 active:scale-[0.97] 
                       focus:outline-none focus:ring-2 focus:ring-blue-300 transition-all duration-200">
                        <i class="mgc_check_fill text-base"></i> Guardar gasto
                    </button>
                </div>
            </form>
        </div>

    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <div wire:ignore
        class="overflow-x-auto rounded-xl border border-gray-200 dark:border-gray-700 p-4 shadow-sm bg-white dark:bg-gray-800">
        <table id="table-docs">
            <thead>
                <tr>
                    <th>Concepto</th>
                    <th>Categoría</th>
                    <th>Fecha</th>
                    <th>Importe (€)</th>
                    <th>Factura</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $gastos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($gasto->concepto); ?></td>
                        <td><?php echo e($gasto->categoria->nombre); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($gasto->fecha_gasto)->format('d/m/Y')); ?></td>
                        <td><?php echo e(number_format($gasto->importe, 2, ',', '.')); ?></td>
                        <td>
                            <!--[if BLOCK]><![endif]--><?php if($gasto->factura_url): ?>
                                <button wire:click="verFactura('<?php echo e(Storage::url($gasto->factura_url)); ?>')"
                                    class="open-pdf-modal inline-flex items-center justify-center w-9 h-9 rounded-full 
                                    bg-blue-100 text-blue-700 border border-blue-200 
                                    hover:bg-blue-200 hover:border-blue-300 transition-all duration-200 shadow-sm">
                                    <i class="mgc_eye_line text-base"></i>
                                </button>
                            <?php else: ?>
                                <span>—</span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </td>
                        <td>
                            <?php if (isset($component)) { $__componentOriginalfaf4cfa089b81cc4b526fd19643bc2b3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfaf4cfa089b81cc4b526fd19643bc2b3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.btns.eliminar','data' => ['wire:click' => 'eliminar('.e($gasto->id).')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btns.eliminar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:click' => 'eliminar('.e($gasto->id).')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfaf4cfa089b81cc4b526fd19643bc2b3)): ?>
<?php $attributes = $__attributesOriginalfaf4cfa089b81cc4b526fd19643bc2b3; ?>
<?php unset($__attributesOriginalfaf4cfa089b81cc4b526fd19643bc2b3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfaf4cfa089b81cc4b526fd19643bc2b3)): ?>
<?php $component = $__componentOriginalfaf4cfa089b81cc4b526fd19643bc2b3; ?>
<?php unset($__componentOriginalfaf4cfa089b81cc4b526fd19643bc2b3); ?>
<?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>

    
    <!--[if BLOCK]><![endif]--><?php if($showModal): ?>
        <div class="fixed inset-0 z-[70] flex items-center justify-center overflow-hidden" aria-modal="true"
            role="dialog" wire:ignore.self>

            
            <div class="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity z-40" wire:click="cerrarVisor">
            </div>

            
            <div
                class="relative w-full max-w-5xl mx-4 rounded-2xl border border-gray-200 dark:border-gray-700
                   bg-white dark:bg-gray-800 shadow-2xl animate-[fadeIn_.15s_ease-out]
                   flex flex-col overflow-hidden h-[95vh] max-h-[95vh] z-50">

                
                <div
                    class="flex items-center justify-between bg-gray-100 dark:bg-gray-800 px-4 py-2
                       border-b border-gray-200 dark:border-gray-700">
                    <div class="flex items-center gap-2 text-gray-700 dark:text-gray-200">
                        <i class="mgc_file_line text-blue-600 text-xl"></i>
                        <span class="text-sm font-medium truncate max-w-[250px]"><?php echo e($archivoNombre); ?></span>
                    </div>
                    <button wire:click="cerrarVisor"
                        class="text-gray-500 hover:text-red-500 text-xl font-bold transition-all duration-200">
                        &times;
                    </button>
                </div>

                
                <div class="flex-1 bg-gray-50 dark:bg-gray-950 relative">

                    
                    <div wire:loading.flex
                        class="absolute inset-0 bg-white/80 dark:bg-gray-900/80 
                            items-center justify-center z-50">
                        <div class="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent">
                        </div>
                    </div>

                    <!--[if BLOCK]><![endif]--><?php if($archivoUrl): ?>
                        <?php
                            $ext = strtolower(pathinfo($archivoUrl, PATHINFO_EXTENSION));
                        ?>

                        
                        <!--[if BLOCK]><![endif]--><?php if($ext === 'pdf'): ?>
                            <iframe src="<?php echo e($archivoUrl); ?>#view=FitH" class="w-full h-full rounded-b-xl"
                                frameborder="0"></iframe>

                            
                        <?php elseif(in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'])): ?>
                            <img src="<?php echo e($archivoUrl); ?>"
                                class="object-contain w-full h-full bg-gray-100 rounded-b-xl">

                            
                        <?php else: ?>
                            <div class="flex items-center justify-center h-full text-gray-500">
                                Formato no compatible para vista previa
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <!--[if BLOCK]><![endif]--><?php if($showExportModal): ?>
    <div class="fixed inset-0 z-[70] flex items-center justify-center overflow-hidden" aria-modal="true"
        role="dialog" wire:ignore.self>

        
        <div class="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
            wire:click="cerrarExportModal"></div>

        
        <div
            class="relative w-full max-w-md mx-4 rounded-2xl border border-gray-200 dark:border-gray-700
                   bg-white dark:bg-gray-800 shadow-2xl animate-[fadeIn_.15s_ease-out]
                   overflow-hidden z-50">

            
            <div class="flex items-center gap-4 p-5 border-b border-gray-100 dark:border-gray-700">
                <div
                    class="w-12 h-12 flex items-center justify-center rounded-xl 
                           bg-blue-100 text-blue-600 dark:bg-blue-900/40 dark:text-blue-300">
                    <i class="mgc_download_2_line text-2xl"></i>
                </div>
                <div>
                    <h3 class="text-lg font-semibold text-gray-900 dark:text-white">Descargar informe</h3>
                    <p class="text-sm text-gray-600 dark:text-gray-400">
                        Selecciona un rango de fechas y el formato del archivo.
                    </p>
                </div>
            </div>

            
            <div class="p-6 space-y-5">
                
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label
                            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Desde</label>
                        <input type="date" wire:model="fechaInicio"
                            class="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600
                                   bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-200 
                                   focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                    </div>
                    <div>
                        <label
                            class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Hasta</label>
                        <input type="date" wire:model="fechaFin"
                            class="w-full px-3 py-2 rounded-lg border border-gray-300 dark:border-gray-600
                                   bg-white dark:bg-gray-900 text-gray-800 dark:text-gray-200 
                                   focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition">
                    </div>
                </div>

                
                <div class="flex flex-col sm:flex-row justify-end gap-3 pt-2">
                    
                    <button wire:click="cerrarExportModal"
                        class="px-4 py-2 rounded-lg border border-gray-300 text-gray-700 
                               hover:bg-gray-50 dark:border-gray-600 dark:text-gray-200 dark:hover:bg-gray-700
                               transition-all duration-200 active:scale-[0.97]">
                        Cancelar
                    </button>

                    
                    <button wire:click="descargarPDF"
                        class="px-4 py-2 rounded-lg bg-red-600 text-white flex items-center gap-2 
                               shadow-sm hover:bg-red-700 focus:ring-2 focus:ring-red-400/50 
                               transition-all duration-200 active:scale-[0.97]">
                        <i class="mgc_pdf_line text-lg"></i>
                        PDF
                    </button>

                    
                    <button wire:click="descargarExcel"
                        class="px-4 py-2 rounded-lg bg-green-600 text-white flex items-center gap-2 
                               shadow-sm hover:bg-green-700 focus:ring-2 focus:ring-green-400/50 
                               transition-all duration-200 active:scale-[0.97]">
                        <i class="mgc_xls_line text-lg"></i>
                        Excel
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/livewire/empresa/gastos/gastos-empresa.blade.php ENDPATH**/ ?>