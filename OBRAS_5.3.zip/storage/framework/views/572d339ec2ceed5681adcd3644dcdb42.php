<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Informe de Materiales</title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            color: #111111;
            background-color: #ffffff;
            margin: 40px;
        }

        /* ===== ENCABEZADO ===== */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #333333;
            padding-bottom: 12px;
            margin-bottom: 25px;
        }

        .header img {
            width: 140px;
            opacity: 0.9;
        }

        .header .info {
            text-align: right;
        }

        .header .info h1 {
            margin: 0;
            font-size: 22px;
            color: #111111;
            letter-spacing: 0.5px;
        }

        .header .info p {
            margin: 2px 0;
            color: #444444;
            font-size: 11.5px;
        }

        /* ===== SEPARADOR OBRA Y FECHA ===== */
        .meta {
            text-align: center;
            color: #555555;
            font-size: 11.5px;
            margin-bottom: 18px;
        }

        /* ===== TABLA ===== */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            border: 1px solid #dddddd;
        }

        th, td {
            border: 1px solid #dddddd;
            padding: 8px 10px;
            font-size: 11.5px;
        }

        th {
            background-color: #f3f4f6;
            font-weight: bold;
            text-transform: uppercase;
            color: #111111;
            font-size: 11px;
            text-align: left;
        }

        td {
            color: #222222;
        }

        tr:nth-child(even) td {
            background-color: #f9f9f9;
        }

        tfoot td {
            background-color: #f5f5f5;
            font-weight: bold;
            border-top: 2px solid #999999;
        }

        /* ===== PIE DE PÁGINA ===== */
        .footer {
            margin-top: 40px;
            text-align: center;
            font-size: 10px;
            color: #555555;
            border-top: 1px solid #cccccc;
            padding-top: 10px;
        }

        /* ===== DETALLES DE EMPRESA (arriba del logo si aplica) ===== */
        .empresa {
            margin-top: 10px;
            color: #333333;
            font-size: 11px;
        }

        .empresa strong {
            font-size: 13px;
            color: #000000;
        }
    </style>
</head>
<body>

    
    <div class="header">
        <?php if(!empty($empresa->logo)): ?>
            <img src="<?php echo e(public_path('storage/' . $empresa->logo)); ?>" alt="Logo <?php echo e($empresa->nombre); ?>">
        <?php else: ?>
            <img src="<?php echo e(public_path('images/logo-dark.png')); ?>" alt="Logo por defecto">
        <?php endif; ?>

        <div class="info">
            <h1>Informe de Materiales</h1>
            <p><strong>Obra:</strong> <?php echo e($obra->nombre); ?></p>
            <p><strong>Fecha:</strong> <?php echo e(now()->format('d/m/Y')); ?></p>
        </div>
    </div>

    
    <div class="empresa">
        <strong><?php echo e($empresa->nombre ?? 'Empresa'); ?></strong><br>
        <?php if(!empty($empresa->direccion)): ?>
            <?php echo e($empresa->direccion); ?><br>
        <?php endif; ?>
        <?php echo e($empresa->codigo_postal ?? ''); ?> <?php echo e($empresa->ciudad ?? ''); ?> <?php echo e(!empty($empresa->provincia) ? '(' . $empresa->provincia . ')' : ''); ?><br>
        <?php if(!empty($empresa->cif)): ?> CIF: <?php echo e($empresa->cif); ?> <?php endif; ?>
        <?php if(!empty($empresa->telefono)): ?> · Tel: <?php echo e($empresa->telefono); ?> <?php endif; ?>
        <?php if(!empty($empresa->email)): ?> · <?php echo e($empresa->email); ?> <?php endif; ?>
    </div>

    
    <div class="meta">
        Documento generado automáticamente el <?php echo e(now()->format('d/m/Y H:i')); ?>

    </div>

    
    <table>
        <thead>
            <tr>
                <th>Material</th>
                <th>Descripción</th>
                <th>Fecha</th>
                <th>Nº Factura</th>
                <th>Cantidad</th>
                <th>Precio Unitario</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <?php $total = 0; ?>
            <?php $__currentLoopData = $materiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $subtotal = $material->cantidad * $material->precio_unitario; ?>
                <tr>
                    <td><?php echo e($material->nombre); ?></td>
                    <td><?php echo e($material->descripcion); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($material->fecha)->format('d/m/Y')); ?></td>
                    <td><?php echo e($material->numero_factura); ?></td>
                    <td><?php echo e($material->cantidad); ?></td>
                    <td><?php echo e(number_format($material->precio_unitario, 2, ',', '.')); ?> €</td>
                    <td><?php echo e(number_format($subtotal, 2, ',', '.')); ?> €</td>
                </tr>
                <?php $total += $subtotal; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="6" style="text-align:right;">Total general:</td>
                <td><?php echo e(number_format($total, 2, ',', '.')); ?> €</td>
            </tr>
        </tfoot>
    </table>

    
    <div class="footer">
        © <?php echo e(date('Y')); ?> <?php echo e($empresa->nombre ?? 'Geocaminos'); ?> — Documento generado automáticamente.
    </div>

</body>
</html>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/obras/gastos/materiales/pdf.blade.php ENDPATH**/ ?>