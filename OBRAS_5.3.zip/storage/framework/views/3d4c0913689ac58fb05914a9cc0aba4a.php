<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'title' => 'Eliminar registro',
    'id' => null,
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'title' => 'Eliminar registro',
    'id' => null,
]); ?>
<?php foreach (array_filter(([
    'title' => 'Eliminar registro',
    'id' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<button type="button"
    <?php echo e($attributes->merge([
        'class' => 'inline-flex items-center justify-center w-9 h-9 rounded-full 
            bg-red-100 text-red-700 border border-red-200 
            hover:bg-red-200 hover:border-red-300 transition-all duration-200 shadow-sm',
    ])); ?>

    title="<?php echo e($title); ?>"  data-id="<?php echo e($id); ?>">
    <i class="mgc_delete_2_line text-lg"></i>
</button>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/components/btns/eliminar.blade.php ENDPATH**/ ?>