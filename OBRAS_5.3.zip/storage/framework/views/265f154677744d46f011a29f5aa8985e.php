<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['pdf', 'title' => 'Ver factura en visor']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['pdf', 'title' => 'Ver factura en visor']); ?>
<?php foreach (array_filter((['pdf', 'title' => 'Ver factura en visor']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<button type="button"
   class="open-pdf-modal inline-flex items-center justify-center w-9 h-9 rounded-full 
          bg-blue-100 text-blue-700 border border-blue-200 
          hover:bg-blue-200 hover:border-blue-300 transition-all duration-200 shadow-sm"
   data-pdf="<?php echo e($pdf); ?>"
   title="<?php echo e($title); ?>">
   <i class="mgc_eye_2_line text-lg"></i>
</button>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/components/btns/ver.blade.php ENDPATH**/ ?>