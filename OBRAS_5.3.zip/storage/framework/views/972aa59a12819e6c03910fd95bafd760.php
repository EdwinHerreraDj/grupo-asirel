<div>
    <div class="space-y-5">

        
        <div>
            
            <div class="flex items-center justify-between mb-6">

                <div class="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-200">
                    <!--[if BLOCK]><![endif]--><?php if($currentFolderId !== 0): ?>
                        <button wire:click="subirNivel"
                            class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-gray-300 bg-white 
                            hover:bg-blue-50 hover:border-blue-300 text-gray-700 hover:text-blue-600
                            dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700 dark:hover:text-blue-400
                            transition-all duration-200">
                            <i class="mgc_arrow_left_line text-base"></i>
                            <span class="hidden sm:inline">Atrás</span>
                        </button>

                        <span class="text-gray-400 dark:text-gray-500">/</span>

                        <div
                            class="flex items-center gap-1 text-blue-600 dark:text-blue-400 truncate max-w-[200px] sm:max-w-[300px]">
                            <i class="mgc_folder_open_line text-base"></i>
                            <span class="truncate"><?php echo e($currentFolder->nombre); ?></span>
                        </div>
                    <?php else: ?>
                        <div class="flex items-center gap-1 text-blue-600 dark:text-blue-400">
                            <i class="mgc_home_3_line text-lg"></i>
                            <span>Raíz</span>
                        </div>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                <div
                    class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 flex-wrap pb-4 border-b border-gray-200 dark:border-gray-700">

                    
                    <div class="flex flex-wrap items-center gap-3">

                        
                        <!--[if BLOCK]><![endif]--><?php if($currentFolderId !== 0): ?>
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('drive.file-manager', ['carpetaId' => $currentFolderId]);

$__html = app('livewire')->mount($__name, $__params, 'file-manager-' . $currentFolderId, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        
                        <button wire:click="toggleFormulario"
                            class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 text-white text-sm font-medium shadow-sm hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 transition">
                            <i class="mgc_add_circle_line text-lg"></i>
                            <span><?php echo e($mostrarFormulario ? 'Cancelar' : 'Nueva carpeta'); ?></span>
                        </button>
                    </div>

                    
                    <div class="flex items-center gap-2 w-full sm:w-auto">
                        <div class="relative flex-1 min-w-[220px]">
                            <input type="text" wire:model.defer="search" placeholder="Buscar archivos o carpetas..."
                                class="w-full pl-10 pr-10 py-2 text-sm border border-gray-300 dark:border-gray-700 rounded-xl
                                bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-100
                                    focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition" />

                            <i
                                class="mgc_search_2_line absolute left-3 top-2.5 text-gray-400 dark:text-gray-500 text-lg"></i>

                            <!--[if BLOCK]><![endif]--><?php if($search): ?>
                                <button wire:click="$set('search', '')"
                                    class="absolute right-3 top-2.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition">
                                    <i class="mgc_close_circle_line text-lg"></i>
                                </button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <button wire:click="buscar"
                            class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 text-white text-sm font-medium shadow-sm hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 transition whitespace-nowrap">
                            <i class="mgc_search_2_line"></i> Buscar
                        </button>
                    </div>
                </div>

            </div>








            
            <!--[if BLOCK]><![endif]--><?php if($mostrarFormulario): ?>
                <div
                    class="relative p-5 border border-blue-200 rounded-xl shadow-md 
                    bg-white dark:bg-gray-800 dark:border-blue-900/40 
                        animate-fadeIn overflow-hidden transition-all duration-300 mb-10">

                    
                    <div class="absolute left-0 top-0 h-full w-1 bg-blue-500/80 rounded-l-xl"></div>

                    
                    <div class="flex items-center gap-3 mb-4">
                        <div
                            class="flex items-center justify-center w-9 h-9 rounded-lg 
                       bg-blue-100 text-blue-600 dark:bg-blue-800 dark:text-blue-300">
                            <i class="mgc_directory_line text-xl"></i>
                        </div>
                        <div>
                            <h3 class="text-base font-semibold text-gray-800 dark:text-gray-100">Crear nueva carpeta
                            </h3>
                            <p class="text-xs text-gray-500 dark:text-gray-400">Organiza y gestiona tus archivos</p>
                        </div>
                    </div>

                    
                    <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                        
                        <input type="text" wire:model.defer="nuevoNombre"
                            class="w-full px-3.5 py-2 border border-gray-300 rounded-md text-gray-800 dark:text-white 
                       dark:bg-gray-800 dark:border-gray-600 placeholder-gray-400
                       focus:ring-1 focus:ring-blue-500 focus:border-blue-500 
                       transition-all duration-200 text-sm"
                            placeholder="Ejemplo: Documentación 2025">

                        
                        <div class="flex gap-2">
                            
                            <button wire:click="crearCarpeta"
                                class="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-md
                           bg-blue-600 text-white text-sm font-medium
                           hover:bg-blue-700 active:scale-[0.98]
                           focus:outline-none focus:ring-2 focus:ring-blue-300 
                           transition-all duration-200">
                                <i class="mgc_check_fill text-base"></i>
                                Guardar
                            </button>

                            
                            <button wire:click="toggleFormulario"
                                class="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-md
                           border border-gray-300 bg-white text-gray-700 text-sm font-medium
                           hover:bg-gray-50 active:scale-[0.98]
                           dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600
                           dark:hover:bg-gray-700 focus:outline-none focus:ring-1 focus:ring-gray-400 
                           transition-all duration-200">
                                <i class="mgc_close_fill text-base"></i>
                                Cancelar
                            </button>
                        </div>
                    </div>

                    
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nuevoNombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 text-xs font-medium mt-2 dark:text-red-400 flex items-center gap-1.5">
                            <i class="mgc_warning_line text-sm"></i> <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->




            
            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-5">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="group relative p-4 rounded-2xl border border-gray-200 bg-gradient-to-br from-white to-blue-50/40 
                        dark:from-gray-800 dark:to-gray-700 dark:border-gray-700 
                            shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-300 cursor-pointer"
                        wire:click="abrirCarpeta(<?php echo e($folder->id); ?>)" x-data="{ open: false }">

                        
                        <div
                            class="flex items-center justify-center w-12 h-12 rounded-xl bg-blue-100 text-blue-600 
                            dark:bg-blue-900/60 dark:text-blue-300 shadow-inner mb-3 cursor-pointer hover:scale-105 transition-transform duration-200">
                            <i class="mgc_folder_2_fill text-3xl"></i>
                        </div>

                        
                        <!--[if BLOCK]><![endif]--><?php if($renamingId === $folder->id): ?>
                            <div class="mt-1" @click.stop>
                                
                                <input type="text" wire:model.defer="nombreEditado"
                                    wire:keydown.enter="guardarRenombrar" wire:keydown.escape="$set('renamingId', null)"
                                    class="w-full px-3.5 py-2 border border-gray-300 rounded-md text-sm text-gray-800 dark:text-white 
                                    dark:bg-gray-800 dark:border-gray-600 placeholder-gray-400
                                    focus:ring-2 focus:ring-blue-500 focus:border-blue-500
                                    shadow-sm transition-all duration-200"
                                    placeholder="Nuevo nombre de carpeta..." autofocus>

                                
                                <div class="flex gap-2 mt-3">
                                    
                                    <button wire:click.stop="guardarRenombrar"
                                        class="inline-flex items-center justify-center gap-1.5 px-4 py-1.5 rounded-md
                                        bg-blue-600 text-white text-sm font-medium
                                        hover:bg-blue-700 active:scale-[0.98]
                                        focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-1 
                                        transition-all duration-200">
                                        <i class="mgc_check_fill text-base"></i>
                                        Guardar
                                    </button>

                                    
                                    <button wire:click.stop="$set('renamingId', null)"
                                        class="inline-flex items-center justify-center gap-1.5 px-4 py-1.5 rounded-md border text-sm font-medium
                                        border-gray-300 text-gray-700 bg-white hover:bg-gray-50 active:scale-[0.98]
                                        dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600 dark:hover:bg-gray-700
                                        focus:outline-none focus:ring-1 focus:ring-gray-400 
                                        transition-all duration-200">
                                        <i class="mgc_close_line text-base"></i>
                                        Cancelar
                                    </button>
                                </div>
                            </div>
                        <?php else: ?>
                            
                            <p class="font-medium text-gray-800 dark:text-gray-100 truncate cursor-pointer">
                                <?php echo e($folder->nombre); ?>

                            </p>

                            
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                <?php echo e($folder->created_at->diffForHumans()); ?>

                            </p>

                            
                            <div class="absolute top-3 right-3" @click.outside="open = false">
                                
                                <button @click.stop="open = !open" wire:ignore.self
                                    class="w-8 h-8 flex items-center justify-center rounded-full 
                                    bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 
                                    hover:bg-gray-200 dark:hover:bg-gray-700 shadow-sm transition">
                                    <i class="mgc_more_2_fill text-lg"></i>
                                </button>

                                
                                <div x-show="open" x-transition.opacity.duration.150ms @click.stop
                                    class="absolute right-0 mt-2 w-44 z-50 
                                    bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700
                                    rounded-xl shadow-xl ring-1 ring-black/5 overflow-hidden text-sm">

                                    
                                    <div
                                        class="px-3 py-2 text-[11px] uppercase tracking-wide text-gray-400 dark:text-gray-500 font-semibold">
                                        Acciones
                                    </div>

                                    <div class="border-t border-gray-100 dark:border-gray-700/50"></div>

                                    
                                    <button wire:click="abrirMover(<?php echo e($folder->id); ?>, 'folder')" @click="open = false"
                                        class="flex items-center gap-2 w-full px-4 py-2.5 text-left 
                                    hover:bg-blue-50 dark:hover:bg-blue-900/30 text-gray-700 dark:text-gray-200 
                                    transition duration-150">
                                        <i class="mgc_arrow_right_line text-blue-500 text-base"></i>
                                        <span>Mover</span>
                                    </button>

                                    
                                    <a href="<?php echo e(route('folders.descargarCarpeta', $folder->id)); ?>"
                                        class="flex items-center gap-2 px-4 py-2.5 
                                        hover:bg-green-50 dark:hover:bg-green-900/30 text-gray-700 dark:text-gray-200 
                                        transition duration-150">
                                        <i class="mgc_archive_line text-green-500 text-base"></i>
                                        <span>Descargar ZIP</span>
                                    </a>

                                    
                                    <button wire:click.stop="iniciarRenombrar(<?php echo e($folder->id); ?>)"
                                        @click="open = false"
                                        class="flex items-center gap-2 w-full px-4 py-2.5 
                                        hover:bg-yellow-50 dark:hover:bg-yellow-900/30 text-gray-700 dark:text-gray-200 
                                        transition duration-150">
                                        <i class="mgc_edit_2_line text-yellow-500 text-base"></i>
                                        <span>Renombrar</span>
                                    </button>

                                    
                                    <button wire:click.stop="confirmarEliminar(<?php echo e($folder->id); ?>)"
                                        @click="open = false"
                                        class="flex items-center gap-2 w-full px-4 py-2.5 
                                        text-red-600 hover:bg-red-50 dark:text-red-400 
                                        dark:hover:bg-red-900/30 transition duration-150">
                                        <i class="mgc_delete_2_line text-red-500 text-base"></i>
                                        <span>Eliminar</span>
                                    </button>
                                </div>

                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->



                
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $extension = strtolower(pathinfo($file->nombre, PATHINFO_EXTENSION));

                        $iconos = [
                            'pdf' => [
                                'icon' => 'mgc_pdf_fill',
                                'color' => 'text-red-600 bg-red-100 dark:bg-red-900/40 dark:text-red-300',
                            ],
                            'doc' => [
                                'icon' => 'mgc_doc_fill',
                                'color' => 'text-blue-600 bg-blue-100 dark:bg-blue-900/40 dark:text-blue-300',
                            ],
                            'docx' => [
                                'icon' => 'mgc_doc_fill',
                                'color' => 'text-blue-600 bg-blue-100 dark:bg-blue-900/40 dark:text-blue-300',
                            ],
                            'xls' => [
                                'icon' => 'mgc_xls_fill',
                                'color' => 'text-green-600 bg-green-100 dark:bg-green-900/40 dark:text-green-300',
                            ],
                            'xlsx' => [
                                'icon' => 'mgc_xls_fill',
                                'color' => 'text-green-600 bg-green-100 dark:bg-green-900/40 dark:text-green-300',
                            ],
                            'ppt' => [
                                'icon' => 'mgc_ppt_fill',
                                'color' => 'text-orange-600 bg-orange-100 dark:bg-orange-900/40 dark:text-orange-300',
                            ],
                            'pptx' => [
                                'icon' => 'mgc_ppt_line',
                                'color' => 'text-orange-600 bg-orange-100 dark:bg-orange-900/40 dark:text-orange-300',
                            ],
                            'jpg' => [
                                'icon' => 'mgc_pic_2_fill',
                                'color' => 'text-pink-600 bg-pink-100 dark:bg-pink-900/40 dark:text-pink-300',
                            ],
                            'jpeg' => [
                                'icon' => 'mgc_pic_2_fill',
                                'color' => 'text-pink-600 bg-pink-100 dark:bg-pink-900/40 dark:text-pink-300',
                            ],
                            'png' => [
                                'icon' => 'mgc_pic_fill',
                                'color' => 'text-pink-600 bg-pink-100 dark:bg-pink-900/40 dark:text-pink-300',
                            ],
                            'gif' => [
                                'icon' => 'mgc_photo_album_fill',
                                'color' => 'text-pink-600 bg-pink-100 dark:bg-pink-900/40 dark:text-pink-300',
                            ],
                            'mp4' => [
                                'icon' => 'mgc_video_fill',
                                'color' => 'text-purple-600 bg-purple-100 dark:bg-purple-900/40 dark:text-purple-300',
                            ],
                            'mov' => [
                                'icon' => 'mgc_video_fill',
                                'color' => 'text-purple-600 bg-purple-100 dark:bg-purple-900/40 dark:text-purple-300',
                            ],
                            'zip' => [
                                'icon' => 'mgc_drawer_2_fill',
                                'color' => 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/40 dark:text-yellow-300',
                            ],
                            'rar' => [
                                'icon' => 'mgc_drawer_2_fill',
                                'color' => 'text-yellow-600 bg-yellow-100 dark:bg-yellow-900/40 dark:text-yellow-300',
                            ],
                            'txt' => [
                                'icon' => 'mgc_copy_line',
                                'color' => 'text-gray-600 bg-gray-100 dark:bg-gray-700 dark:text-gray-300',
                            ],
                            'default' => [
                                'icon' => 'mgc_copy_line',
                                'color' => 'text-gray-600 bg-gray-100 dark:bg-gray-700 dark:text-gray-300',
                            ],
                        ];

                        $icono = $iconos[$extension] ?? $iconos['default'];
                    ?>

                    <div
                        class="group relative p-4 rounded-2xl border border-gray-200 bg-gradient-to-br from-white to-gray-50 
                        dark:from-gray-800 dark:to-gray-700 dark:border-gray-700 
                        shadow-sm hover:shadow-md hover:-translate-y-1 transition-all duration-300">

                        
                        <div
                            class="flex items-center justify-center w-12 h-12 rounded-xl shadow-inner mb-3 <?php echo e($icono['color']); ?>">
                            <i class="<?php echo e($icono['icon']); ?> text-3xl"></i>
                        </div>

                        <p
                            class="text-xs mt-2 flex items-center font-medium
                            <!--[if BLOCK]><![endif]--><?php if($file->fecha_caducidad && \Carbon\Carbon::parse($file->fecha_caducidad)->isPast()): ?> text-red-600 
                            <?php elseif($file->fecha_caducidad && \Carbon\Carbon::parse($file->fecha_caducidad)->diffInDays(now()) <= 7): ?> text-yellow-600 
                            <?php else: ?> text-gray-500 dark:text-gray-400 <?php endif; ?>">

                            <!--[if BLOCK]><![endif]--><?php if($file->fecha_caducidad): ?>
                                
                                <!--[if BLOCK]><![endif]--><?php if(\Carbon\Carbon::parse($file->fecha_caducidad)->isPast()): ?>
                                    <i class="mgc_alert_fill text-[13px]"></i>
                                <?php elseif(\Carbon\Carbon::parse($file->fecha_caducidad)->diffInDays(now()) <= 7): ?>
                                    <i class="mgc_timer_line text-[13px]"></i>
                                <?php else: ?>
                                    <i class="mgc_calendar_line text-[13px]"></i>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                
                                Vence:
                                <span class="ml-1 font-semibold">
                                    <?php echo e(\Carbon\Carbon::parse($file->fecha_caducidad)->format('d/m/Y')); ?>

                                </span>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </p>


                        
                        <p class="font-medium text-gray-800 dark:text-gray-100 truncate">
                            <?php echo e($file->nombre); ?>

                        </p>




                        
                        <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                            <?php echo e(number_format($file->tamaño / 1024, 1)); ?> KB
                        </p>

                        
                        <div class="absolute top-3 right-3">
                            <div x-data="{ open: false }" class="relative">
                                <button @click="open = !open"
                                    class="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                                    <i class="mgc_more_2_fill text-gray-600 dark:text-gray-300"></i>
                                </button>

                                
                                <div x-show="open" @click.outside="open = false" x-transition
                                    class="absolute right-0 mt-2 w-40 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-lg z-50">
                                    <ul class="text-sm text-gray-700 dark:text-gray-200">
                                        
                                        <li>
                                            <button wire:click="abrirMover(<?php echo e($file->id); ?>, 'file')"
                                                class="w-full text-left px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                                                <i class="mgc_arrow_right_line mr-2"></i> Mover
                                            </button>
                                        </li>


                                        
                                        <li>
                                            <a href="<?php echo e(route('files.descargar', $file->id)); ?>" target="_blank"
                                                class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                                                <i class="mgc_download_2_line mr-2"></i> Descargar
                                            </a>
                                        </li>

                                        
                                        <li>
                                            <button wire:click="confirmarEliminarArchivo(<?php echo e($file->id); ?>)"
                                                class="w-full text-left px-4 py-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-800/40 transition">
                                                <i class="mgc_delete_2_line mr-2"></i> Eliminar
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                
                <!--[if BLOCK]><![endif]--><?php if($folders->isEmpty() && $files->isEmpty()): ?>
                    <div class="col-span-full text-center text-gray-500 dark:text-gray-400 py-10">
                        <i class="mgc_inbox_2_line text-5xl mb-3 text-gray-400 dark:text-gray-500"></i>
                        <!--[if BLOCK]><![endif]--><?php if(trim($search) !== ''): ?>
                            <p class="text-sm">No se encontraron resultados para “<?php echo e($search); ?>”.</p>
                        <?php else: ?>
                            <p class="text-sm">No hay contenido en esta carpeta.</p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            </div>
        </div>




        
        <style>
            @keyframes fadeIn {
                from {
                    opacity: 0;
                    transform: translateY(-5px);
                }

                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .animate-fadeIn {
                animation: fadeIn 0.2s ease-in-out;
            }
        </style>

        
        <!--[if BLOCK]><![endif]--><?php if($showDeleteModal): ?>
            <div class="fixed inset-0 z-[70] flex items-center justify-center overflow-hidden" style="inset:0;"
                aria-modal="true" role="dialog" wire:ignore.self>
                
                <div class="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
                    wire:click="cancelarEliminar">
                </div>

                
                <div
                    class="relative w-full max-w-md mx-4 rounded-2xl border border-gray-200 dark:border-gray-700
                   bg-white dark:bg-gray-800 shadow-2xl animate-[fadeIn_.15s_ease-out]">
                    <div class="p-6">
                        <div class="flex items-center gap-3 mb-4">
                            <div
                                class="w-10 h-10 rounded-xl flex items-center justify-center
                            bg-red-100 text-red-600 dark:bg-red-900/40 dark:text-red-300">
                                <i class="mgc_warning_fill text-2xl"></i>
                            </div>
                            <div>
                                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                                    Confirmar eliminación
                                </h3>
                                <p class="text-sm text-gray-600 dark:text-gray-400">
                                    Esta acción no se puede deshacer.
                                </p>
                            </div>
                        </div>

                        <div class="mt-2 text-sm text-gray-700 dark:text-gray-300">
                            ¿Seguro que deseas eliminar la carpeta
                            <span class="font-medium text-gray-900 dark:text-white">"<?php echo e($deletingName); ?>"</span>?
                        </div>

                        
                        <!--[if BLOCK]><![endif]--><?php if($deleteError): ?>
                            <p class="mt-4 text-sm font-medium text-red-600 dark:text-red-400 flex items-center gap-2">
                                <i class="mgc_warning_line text-base"></i> <?php echo e($deleteError); ?>

                            </p>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                        <div class="mt-6 flex items-center justify-end gap-3">
                            <button
                                class="px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50
                           dark:border-gray-600 dark:text-gray-200 dark:hover:bg-gray-700"
                                wire:click="cancelarEliminar">
                                Cancelar
                            </button>
                            <button
                                class="px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 flex items-center gap-2"
                                wire:click="eliminarConfirmado">
                                <i class="mgc_delete_2_fill text-lg"></i>
                                Sí, eliminar
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <!--[if BLOCK]><![endif]--><?php if($showDeleteFileModal): ?>
            <div class="fixed inset-0 z-[70] flex items-center justify-center overflow-hidden" style="inset:0;"
                aria-modal="true" role="dialog" wire:ignore.self>
                
                <div class="fixed inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
                    wire:click="cancelarEliminarArchivo">
                </div>

                
                <div
                    class="relative w-full max-w-md mx-4 rounded-2xl border border-gray-200 dark:border-gray-700
                   bg-white dark:bg-gray-800 shadow-2xl animate-[fadeIn_.15s_ease-out]">
                    <div class="p-6">
                        <div class="flex items-center gap-3 mb-4">
                            <div
                                class="w-10 h-10 rounded-xl flex items-center justify-center
                            bg-red-100 text-red-600 dark:bg-red-900/40 dark:text-red-300">
                                <i class="mgc_warning_fill text-2xl"></i>
                            </div>
                            <div>
                                <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                                    Confirmar eliminación
                                </h3>
                                <p class="text-sm text-gray-600 dark:text-gray-400">
                                    Esta acción eliminará el archivo permanentemente.
                                </p>
                            </div>
                        </div>

                        
                        <div class="mt-2 text-sm text-gray-700 dark:text-gray-300">
                            <!--[if BLOCK]><![endif]--><?php if($deleteFileError): ?>
                                <p class="font-medium text-red-600 dark:text-red-400 flex items-center gap-2">
                                    <i class="mgc_warning_line text-base"></i> <?php echo e($deleteFileError); ?>

                                </p>
                            <?php else: ?>
                                ¿Seguro que deseas eliminar el archivo
                                <span class="font-medium text-gray-900 dark:text-white">
                                    "<?php echo e($deletingFileName); ?>"
                                </span>?
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        
                        <div class="mt-6 flex items-center justify-end gap-3">
                            <button
                                class="px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50
                           dark:border-gray-600 dark:text-gray-200 dark:hover:bg-gray-700 transition"
                                wire:click="cancelarEliminarArchivo">
                                Cancelar
                            </button>
                            <button
                                class="px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 flex items-center gap-2"
                                wire:click="eliminarArchivoConfirmado">
                                <i class="mgc_delete_2_fill text-lg"></i>
                                Sí, eliminar
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <style>
                @keyframes fadeIn {
                    from {
                        opacity: 0;
                        transform: translateY(4px);
                    }

                    to {
                        opacity: 1;
                        transform: translateY(0);
                    }
                }
            </style>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        
        <!--[if BLOCK]><![endif]--><?php if($showMoveModal): ?>
            <div class="fixed inset-0 z-[70] flex items-center justify-center" aria-modal="true" role="dialog">
                
                <div class="fixed inset-0 bg-black/60 backdrop-blur-sm" wire:click="$set('showMoveModal', false)">
                </div>

                
                <div
                    class="relative w-full max-w-md mx-4 rounded-2xl border border-gray-200 dark:border-gray-700
                    bg-white dark:bg-gray-800 shadow-2xl animate-[fadeIn_.15s_ease-out] p-6">

                    
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-lg font-semibold text-gray-900 dark:text-white">
                            <i class="mgc_arrow_right_line mr-1.5 text-blue-600 dark:text-blue-400"></i>
                            Mover <?php echo e($movingType === 'file' ? 'archivo' : 'carpeta'); ?>

                        </h3>
                        <button wire:click="$set('showMoveModal', false)"
                            class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition">
                            <i class="mgc_close_line text-xl"></i>
                        </button>
                    </div>

                    
                    <p class="text-sm text-gray-500 dark:text-gray-400 mb-4 leading-relaxed">
                        Selecciona la carpeta destino donde quieres mover
                        <?php echo e($movingType === 'file' ? 'este archivo' : 'esta carpeta'); ?>.
                    </p>

                    
                    <div class="relative">
                        <i class="mgc_folder_2_line absolute left-3 top-2.5 text-gray-400 dark:text-gray-500"></i>
                        <select wire:model="destinationFolderId"
                            class="w-full pl-10 border border-gray-300 dark:border-gray-600 rounded-xl py-2.5 text-sm
                           bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-100 
                           focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition">
                            <option value="">-- Selecciona carpeta --</option>
                            <option value="0">Mover a la raíz</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->obtenerCarpetasJerarquicas(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($folder['id']); ?>">
                                    <?php echo e(str_repeat('⎯⎯ ', $folder['nivel'] ?? 0) . $folder['nombre']); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>

                    
                    <div class="flex justify-end gap-3 mt-6">
                        <button wire:click="$set('showMoveModal', false)"
                            class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg border border-gray-300 
                           dark:border-gray-600 text-gray-700 dark:text-gray-200 
                           hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                            <i class="mgc_close_line text-base"></i> Cancelar
                        </button>

                        <button wire:click="moverElemento"
                            class="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 
                           text-white font-medium hover:bg-blue-700 active:scale-[0.98] 
                           focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-1 
                           transition">
                            <i class="mgc_arrow_right_up_line text-base"></i> Confirmar
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->



    </div>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/livewire/drive/folder-manager.blade.php ENDPATH**/ ?>