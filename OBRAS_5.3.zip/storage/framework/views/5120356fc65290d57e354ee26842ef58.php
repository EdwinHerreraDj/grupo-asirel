<?php echo app('Illuminate\Foundation\Vite')(['resources/scss/app.scss', 'resources/scss/icons.scss']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/head.js', 'resources/js/config.js']); ?>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/layouts/shared/head-css.blade.php ENDPATH**/ ?>