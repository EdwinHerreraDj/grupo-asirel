<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            color: #1f2937;
            margin: 20px;
        }

        /* === ENCABEZADO EMPRESA === */
        .empresa {
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #059669;
        }

        .empresa strong {
            font-size: 14px;
            color: #047857;
        }

        .empresa p {
            margin: 2px 0;
            color: #374151;
            font-size: 11px;
        }

        /* === TITULOS === */
        h2 {
            text-align: center;
            font-weight: bold;
            color: #065f46;
            margin-bottom: 4px;
        }

        .meta {
            text-align: center;
            color: #4b5563;
            font-size: 11px;
            margin-bottom: 10px;
        }

        /* === TABLA === */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th, td {
            border: 1px solid #e5e7eb;
            padding: 6px 8px;
            text-align: right;
            vertical-align: middle;
        }

        th {
            background-color: #a7f3d0;
            color: #064e3b;
            font-weight: bold;
        }

        td:first-child, th:first-child {
            text-align: left;
        }

        tr:nth-child(even) td {
            background-color: #f9fafb;
        }

        /* === COLORES DE VALOR === */
        .negativo {
            color: #b91c1c;
            font-weight: bold;
        }

        .positivo {
            color: #065f46;
            font-weight: bold;
        }

        /* === TOTALES === */
        tfoot td {
            font-weight: bold;
            background-color: #ecfdf5;
            border-top: 2px solid #059669;
        }

        /* === DATOS === */
        .datos {
            text-align: center;
            color: #6b7280;
            font-size: 11px;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>

    
    <?php if(isset($empresa)): ?>
        <div class="empresa">
            <strong><?php echo e($empresa->nombre ?? 'Empresa'); ?></strong><br>
            <?php if(!empty($empresa->direccion)): ?>
                <p><?php echo e($empresa->direccion); ?></p>
            <?php endif; ?>
            <?php if(!empty($empresa->codigo_postal) || !empty($empresa->ciudad)): ?>
                <p><?php echo e($empresa->codigo_postal ?? ''); ?> <?php echo e($empresa->ciudad ?? ''); ?> <?php echo e(!empty($empresa->provincia) ? '(' . $empresa->provincia . ')' : ''); ?></p>
            <?php endif; ?>
            <p>
                <?php if(!empty($empresa->cif)): ?> CIF: <?php echo e($empresa->cif); ?> <?php endif; ?>
                <?php if(!empty($empresa->telefono)): ?> · Tel: <?php echo e($empresa->telefono); ?> <?php endif; ?>
            </p>
            <?php if(!empty($empresa->email) || !empty($empresa->sitio_web)): ?>
                <p>
                    <?php if(!empty($empresa->email)): ?> <?php echo e($empresa->email); ?> <?php endif; ?>
                    <?php if(!empty($empresa->sitio_web)): ?> · <?php echo e($empresa->sitio_web); ?> <?php endif; ?>
                </p>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    
    <h2>Informe Coste - Venta Mensual</h2>
    <p class="meta">
        <strong>% Gastos Internos:</strong> <?php echo e($filtros['porcentaje'] ?? 0); ?>% |
        <strong>Generado:</strong> <?php echo e(now()->format('d/m/Y H:i')); ?>

    </p>

    
    <table>
        <thead>
            <tr>
                <th>Obra</th>
                <th>Mes</th>
                <th>Coste Real (€)</th>
                <th>% Extra</th>
                <th>Coste Ajustado (€)</th>
                <th>Facturación (€)</th>
                <th>Beneficio (€)</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($r['obra']); ?></td>
                    <td><?php echo e($r['mes']); ?></td>
                    <td><?php echo e(number_format($r['coste_real'], 2, ',', '.')); ?></td>
                    <td><?php echo e($r['porcentaje']); ?>%</td>
                    <td><?php echo e(number_format($r['coste_ajustado'], 2, ',', '.')); ?></td>
                    <td><?php echo e(number_format($r['facturacion'], 2, ',', '.')); ?></td>
                    <td class="<?php echo e($r['beneficio'] < 0 ? 'negativo' : 'positivo'); ?>">
                        <?php echo e(number_format($r['beneficio'], 2, ',', '.')); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>
</html>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/exports/informes/coste-venta-mensual.blade.php ENDPATH**/ ?>