

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-12">
        <div class="col-span-12">

            
            <?php echo $__env->make('./notifications/notyf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



            <div class="card p-10">
                <div>
                    <div class="mb-5">
                        <h2 class="text-2xl font-semibold text-gray-800 dark:text-white mb-1">Mi unidad</h2>
                        <p class="text-gray-600 dark:text-gray-400">Gestiona la información de tu empresa aquí.</p>
                    </div>
                    <div>
                        <button
                            class="inline-flex items-center gap-2 px-4 py-2 mb-4 rounded-full bg-green-500/20 text-green-700 font-medium border border-green-500/30 
                            shadow-sm hover:bg-green-600 hover:text-white transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-green-400/40"
                            data-fc-type="modal" data-fc-target="empresa" type="button">
                            <i class="mgc_settings_5_line"></i> Configuración
                        </button>
                    </div>
                </div>

                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('empresa.empresa-info', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3111018703-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-8">

                <!-- Drive App -->
                <a href="<?php echo e(route('empresa.driveApp')); ?>"
                    class="flex flex-col items-center justify-center gap-3 p-6 bg-white dark:bg-slate-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm hover:shadow-md hover:border-blue-500 transition-all duration-300 group">
                    <i class="mgc_album_2_line text-3xl text-blue-600 group-hover:scale-110 transition-transform"></i>
                    <span class="text-base font-semibold text-gray-800 dark:text-gray-100">Drive App</span>
                    <p class="text-sm text-gray-500 dark:text-gray-400 text-center">Accede a los archivos y documentos de la
                        empresa</p>
                </a>

                <!-- Gastos de la empresa -->
                <a href="<?php echo e(route('empresa.gastosEmpresa')); ?>"
                    class="flex flex-col items-center justify-center gap-3 p-6 bg-white dark:bg-slate-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm hover:shadow-md hover:border-emerald-500 transition-all duration-300 group">
                    <i class="mgc_chart_line_line text-3xl text-emerald-600 group-hover:scale-110 transition-transform"></i>
                    <span class="text-base font-semibold text-gray-800 dark:text-gray-100">Gastos de la Empresa</span>
                    <p class="text-sm text-gray-500 dark:text-gray-400 text-center">Consulta y gestiona los gastos generales
                    </p>
                </a>

                <!-- Informes -->
                <a href="<?php echo e(route('informes.index')); ?>"
                    class="flex flex-col items-center justify-center gap-3 p-6 bg-white dark:bg-slate-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-sm hover:shadow-md hover:border-indigo-500 transition-all duration-300 group">
                    <i class="mgc_book_5_line text-3xl text-indigo-600 group-hover:scale-110 transition-transform"></i>
                    <span class="text-base font-semibold text-gray-800 dark:text-gray-100">Informes</span>
                    <p class="text-sm text-gray-500 dark:text-gray-400 text-center">Visualiza reportes financieros y
                        estadísticos</p>
                </a>

            </div>



        </div>
    </div>

    <?php echo $__env->make('empresa.modals.create-edit-empresa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/empresa.js']); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['title' => 'Mi unidad', 'sub_title' => 'Pages', 'mode' => $mode ?? '', 'demo' => $demo ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/empresa/index.blade.php ENDPATH**/ ?>