

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-12">
        <div class="col-span-12">
            


            <div class="card p-10">
                <div>
                    <a href="<?php echo e(route('empresa.index')); ?>"
                        class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-700 font-medium shadow-sm border border-gray-200 
               hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-primary/30 mb-7">
                        <i class="mgc_arrow_left_line text-lg"></i>
                        Regresar
                    </a>
                    <hr class="mb-3">
                    <div class="mb-5">
                        <h2 class="text-2xl font-semibold text-gray-800 dark:text-white mb-1">Drive App</h2>
                        <p class="text-gray-600 dark:text-gray-400">Gestiona las carpetas y archivos de tu empresa aquí.</p>
                    </div>
                </div>

                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('drive.folder-manager', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-268282535-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        window.addEventListener('toast', e => {
            const {
                type,
                text
            } = e.detail;
            if (type === 'success') {
                Notyf.success(text);
            } else if (type === 'error') {
                Notyf.error(text);
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['title' => 'Drive App', 'sub_title' => 'Pages', 'mode' => $mode ?? '', 'demo' => $demo ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/empresa/drive/folders.blade.php ENDPATH**/ ?>