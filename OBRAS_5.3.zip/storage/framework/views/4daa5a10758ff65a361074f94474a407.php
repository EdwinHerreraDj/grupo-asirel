<meta charset="utf-8">
<title><?php echo e($title ?? ''); ?> | Obras</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="App Web desarrollo Obras" name="description">
<meta content="Alminares.es" name="author">

<!-- App favicon -->
<link rel="shortcut icon" href="/images/favicon.ico">
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/layouts/shared/title-meta.blade.php ENDPATH**/ ?>