 
 <form id="form-delete" method="POST" style="display:none;">
     <?php echo csrf_field(); ?>
     <?php echo method_field('DELETE'); ?>
 </form>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/obras/components-obras/form-delete.blade.php ENDPATH**/ ?>