

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-12">
        <div class="col-span-12 card p-10">

            
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('empresa.gastos.barra-acciones', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3944219475-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('empresa.gastos.categorias-gasto-empresa', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3944219475-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('empresa.gastos.gastos-empresa', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3944219475-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['title' => 'Gastos empresa', 'sub_title' => 'Pages', 'mode' => $mode ?? '', 'demo' => $demo ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/empresa/gastos_empresa/index.blade.php ENDPATH**/ ?>