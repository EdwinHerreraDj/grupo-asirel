<!DOCTYPE html>
<html lang="es">

<head>
    <?php echo $__env->make('layouts.shared/title-meta', ['title' => 'Login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.shared/head-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

    <div class="bg-gradient-to-r from-rose-100 to-teal-100 dark:from-gray-700 dark:via-gray-900 dark:to-black">


        <div class="h-screen w-screen flex justify-center items-center">

            <div class="2xl:w-1/4 lg:w-1/3 md:w-1/2 w-full">
                <div class="card overflow-hidden sm:rounded-md rounded-none">
                    <div class="p-6">
                        <a href="<?php echo e(route('any', 'index')); ?>" class="block mb-8">
                            <img class="h-48 w-30 block dark:hidden" src="/images/logo-dark.png" alt="">
                            <img class="h-6 hidden dark:block" src="/images/logo-light.png" alt="">
                        </a>

                        <?php if($errors->has('login')): ?>
                        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md flex items-center mb-4" role="alert">
                            <div>
                                <p class="font-bold text-sm">Error</p>
                                <p class="text-sm"><?php echo e($errors->first('login')); ?></p>
                            </div>
                        </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-600 dark:text-gray-200 mb-2"
                                    for="LoggingEmailAddress">Email</label>
                                <input id="LoggingEmailAddress" class="form-input" type="email"
                                    placeholder="Ingrese su email" name="email" value="<?php echo e(old('email')); ?>">
                            </div>

                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-600 dark:text-gray-200 mb-2"
                                    for="loggingPassword">Password</label>
                                <input id="loggingPassword" class="form-input" type="password"
                                    placeholder="Ingrese su contraseña" name="password" value="<?php echo e(old('password')); ?>">
                            </div>

                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center">
                                    <input type="checkbox" class="form-checkbox rounded" id="checkbox-signin">
                                    <label class="ms-2" for="checkbox-signin">Recordar Sesión</label>
                                </div>
                                <a href="<?php echo e(route('second', ['auth', 'recoverpw'])); ?>"
                                    class="text-sm text-primary border-b border-dashed border-primary">Olvidaste tu
                                    contraseña?</a>
                            </div>

                            <div class="flex justify-center mb-6">
                                <button class="btn w-full text-white bg-primary">Acceder</button>
                            </div>
                        </form>

                        <p class="text-gray-500 dark:text-gray-400 text-center">Soporte tecnico ®<a
                                href="<?php echo e(route('register')); ?>" class="text-primary ms-1"><b>Alminares S.L</b></a>
                        </p>
                    </div>
                </div>
            </div>
        </div>

    </div>

</body>

</html>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/auth/login.blade.php ENDPATH**/ ?>