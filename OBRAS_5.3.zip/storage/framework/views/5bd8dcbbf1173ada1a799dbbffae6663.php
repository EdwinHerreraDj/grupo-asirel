<!DOCTYPE html>
<html lang="es" data-sidenav-view="<?php echo e($sidenav ?? 'default'); ?>">

<head>
    <?php echo $__env->make('layouts.shared/title-meta', ['title' => $title, ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('css'); ?>
    <?php echo $__env->make('layouts.shared/head-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link href="https://cdn.datatables.net/v/dt/dt-2.1.8/datatables.min.css" rel="stylesheet">
    <!-- CSS de Notyf -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/notyf/notyf.min.css">
    <!-- JS de Notyf -->
    <script src="https://cdn.jsdelivr.net/npm/notyf/notyf.min.js"></script>
    <!-- CSS de SweetAlert2 -->
    <?php echo app('Illuminate\Foundation\Vite')(['node_modules/sweetalert2/dist/sweetalert2.min.css']); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>


</head>

<body>

    <div class="flex wrapper">

        <?php echo $__env->make('layouts.shared/sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="page-content">

            <?php echo $__env->make('layouts.shared/topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <main class="flex-grow p-6">

                <?php echo $__env->make('layouts.shared/page-title', [
                    'title' => $title,
                    'sub_title' => $sub_title,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->yieldContent('content'); ?>

            </main>

            <?php echo $__env->make('layouts.shared/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

    </div>

    <?php echo $__env->make('layouts.shared/customizer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.shared/footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.datatables.net/v/dt/dt-2.1.8/datatables.min.js"></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/tables-datatable.js', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


    <script>
        // Crear instancia global de Notyf
        const notyf = new Notyf({
            duration: 3000,
            position: {
                x: 'right',
                y: 'top'
            },
            dismissible: true,
        });

        // Escuchar los eventos Livewire tipo "toast"
        window.addEventListener('toast', (event) => {
            const {
                type,
                text
            } = event.detail;
            if (type === 'success') {
                notyf.success(text);
            } else if (type === 'error') {
                notyf.error(text);
            } else {
                notyf.open({
                    type: 'info',
                    message: text
                });
            }
        });
       
    </script>


</body>

</html>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/layouts/vertical.blade.php ENDPATH**/ ?>