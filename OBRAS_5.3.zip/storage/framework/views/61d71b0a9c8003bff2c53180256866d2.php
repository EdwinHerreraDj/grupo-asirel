

<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-12">
        <div class="col-span-12">
            <a href="<?php echo e(route('empresa.index')); ?>"
                class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-700 font-medium shadow-sm border border-gray-200 
               hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-primary/30 mb-7">
                <i class="mgc_arrow_left_line text-lg"></i>
                Regresar
            </a>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('informes.informes-general', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2232565416-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['title' => 'Informes', 'sub_title' => 'Pages', 'mode' => $mode ?? '', 'demo' => $demo ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/empresa/informes/index.blade.php ENDPATH**/ ?>