<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Informe de Gastos de Empresa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 30px;
            color: #333;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .header img {
            width: 180px;
        }

        .header .info {
            text-align: right;
        }

        .header .info h1 {
            margin: 0;
            font-size: 26px;
            color: #333;
        }

        .header .info p {
            margin: 2px 0;
            color: #666;
            font-size: 13px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #f9f9f9;
        }

        .table th,
        .table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .table td {
            font-size: 11px;
        }

        .table th {
            background-color: #f2f2f2;
            font-weight: bold;
            text-transform: uppercase;
            font-size: 12px;
            color: #555;
        }

        .table tfoot td {
            font-weight: bold;
            background-color: #f2f2f2;
        }

        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 12px;
            color: #888;
        }
    </style>
</head>

<body>
    <!-- Encabezado -->
    <div class="header">
        <img src="<?php echo e(public_path('images/logo-dark.png')); ?>" alt="Logo">
        <div class="info">
            <h1>Informe de Gastos</h1>
            <p><strong>Fecha del informe:</strong> <?php echo e(now()->format('d/m/Y')); ?></p>
            <?php if(!empty(request('inicio')) || !empty(request('fin'))): ?>
                <p>
                    <strong>Periodo:</strong>
                    <?php if(request('inicio') && request('fin')): ?>
                        <?php echo e(\Carbon\Carbon::parse(request('inicio'))->format('d/m/Y')); ?>

                        — <?php echo e(\Carbon\Carbon::parse(request('fin'))->format('d/m/Y')); ?>

                    <?php elseif(request('inicio')): ?>
                        Desde <?php echo e(\Carbon\Carbon::parse(request('inicio'))->format('d/m/Y')); ?>

                    <?php elseif(request('fin')): ?>
                        Hasta <?php echo e(\Carbon\Carbon::parse(request('fin'))->format('d/m/Y')); ?>

                    <?php endif; ?>
                </p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Tabla de Gastos -->
    <table class="table">
        <thead>
            <tr>
                <th>Concepto</th>
                <th>Categoría</th>
                <th>Fecha</th>
                <th>Importe (€)</th>
                <th>Descripción</th>
            </tr>
        </thead>
        <tbody>
            <?php $total = 0; ?>
            <?php $__currentLoopData = $gastos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($gasto->concepto); ?></td>
                    <td><?php echo e($gasto->categoria->nombre ?? '—'); ?></td>
                    <td>
                        <?php echo e($gasto->fecha_gasto ? \Carbon\Carbon::parse($gasto->fecha_gasto)->format('d/m/Y') : 'Sin fecha'); ?>

                    </td>
                    <td><?php echo e(number_format($gasto->importe, 2, ',', '.')); ?> €</td>
                    <td><?php echo e($gasto->descripcion ?: '—'); ?></td>
                </tr>
                <?php $total += $gasto->importe; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" style="text-align: right;">Total general:</td>
                <td colspan="2"><?php echo e(number_format($total, 2, ',', '.')); ?> €</td>
            </tr>
        </tfoot>
    </table>

    <!-- Pie de página -->
    <div class="footer">
        <p>© <?php echo e(date('Y')); ?> Alminares S.L. Todos los derechos reservados.</p>
    </div>
</body>

</html>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/empresa/gastos_empresa/gastos_empresa_pdf.blade.php ENDPATH**/ ?>