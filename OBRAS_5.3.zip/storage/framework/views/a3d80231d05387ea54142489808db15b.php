 <!-- bundle -->
 <?php echo $__env->yieldContent('script'); ?>
 <!-- App js -->
 <?php echo $__env->yieldContent('script-bottom'); ?>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/layouts/shared/footer-scripts.blade.php ENDPATH**/ ?>