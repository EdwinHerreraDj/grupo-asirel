


<?php $__env->startSection('css'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="grid grid-cols-12">
        <div class="col-span-12">

            
            <?php echo $__env->make('./notifications/notyf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="card p-10">
                
                <a href="<?php echo e(route('obras.gastos', $obra->id)); ?>"
                    class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gray-100 text-gray-700 font-medium shadow-sm border border-gray-200 
               hover:bg-gray-200 hover:text-gray-900 transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-primary/30">
                    <i class="mgc_arrow_left_line text-lg"></i>
                    Regresar
                </a>

                <!-- Botón Agregar Gasto -->
                <button type="button" data-fc-type="modal"
                    class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/20 text-green-700 font-medium border border-green-500/30 
               shadow-sm hover:bg-green-600 hover:text-white transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-green-400/40">
                    <i class="mgc_add_line text-lg"></i>
                    Agregar gasto
                </button>

                
                <?php echo $__env->make('obras.gastos.materiales.modal.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                


                <button type="button" data-fc-type="modal" data-fc-target="informe"
                    class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/20 text-cyan-700 font-medium border border-cyan-500/30 
                    shadow-sm hover:bg-cyan-600 hover:text-white transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-cyan-400/40">
                    <i class="mgc_add_line text-lg"></i>
                    Generar informe
                </button>


                
                <?php echo $__env->make('obras.gastos.materiales.modal.informe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



                

                <div class="mt-5">
                    <h2 class="text-lg font-semibold text-gray-50 mb-2 bg-primary p-3 rounded">Gasto Materiales</h2>
                    <div class="overflow-x-auto">
                        <table id="table-docs" class="display">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nombre</th>
                                    <th>Descripcion</th>
                                    <th>Valor Unitario</th>
                                    <th>Cantidad</th>
                                    <th>Importe</th>
                                    <th>Factura</th>
                                    <th>Numero de factura</th>
                                    <th>Fecha</th>
                                    <th>Accion</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $obra->materiales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($material->nombre); ?></td>
                                        <td><?php echo e($material->descripcion); ?></td>
                                        <td><?php echo e($material->precio_unitario); ?> €</td>
                                        <td><?php echo e($material->cantidad); ?></td>
                                        <td><?php echo e(number_format($material->importe, 2, ',', '.')); ?> €</td>
                                        <td>
                                            <?php if (isset($component)) { $__componentOriginaldc64d552cfeec60403dcbc954bcfb8c5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldc64d552cfeec60403dcbc954bcfb8c5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.btns.descargar','data' => ['href' => ''.e(asset('storage/' . $material->archivo_factura)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btns.descargar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(asset('storage/' . $material->archivo_factura)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldc64d552cfeec60403dcbc954bcfb8c5)): ?>
<?php $attributes = $__attributesOriginaldc64d552cfeec60403dcbc954bcfb8c5; ?>
<?php unset($__attributesOriginaldc64d552cfeec60403dcbc954bcfb8c5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldc64d552cfeec60403dcbc954bcfb8c5)): ?>
<?php $component = $__componentOriginaldc64d552cfeec60403dcbc954bcfb8c5; ?>
<?php unset($__componentOriginaldc64d552cfeec60403dcbc954bcfb8c5); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginalbd8b85e9fd2d6e48014989c07385a99b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbd8b85e9fd2d6e48014989c07385a99b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.btns.ver','data' => ['pdf' => ''.e(asset('storage/' . $material->archivo_factura)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btns.ver'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pdf' => ''.e(asset('storage/' . $material->archivo_factura)).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbd8b85e9fd2d6e48014989c07385a99b)): ?>
<?php $attributes = $__attributesOriginalbd8b85e9fd2d6e48014989c07385a99b; ?>
<?php unset($__attributesOriginalbd8b85e9fd2d6e48014989c07385a99b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbd8b85e9fd2d6e48014989c07385a99b)): ?>
<?php $component = $__componentOriginalbd8b85e9fd2d6e48014989c07385a99b; ?>
<?php unset($__componentOriginalbd8b85e9fd2d6e48014989c07385a99b); ?>
<?php endif; ?>
                                        </td>
                                        <td><?php echo e($material->numero_factura); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($material->fecha)->format('d/m/Y')); ?></td>

                                        <td>
                                            <?php if (isset($component)) { $__componentOriginalfaf4cfa089b81cc4b526fd19643bc2b3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfaf4cfa089b81cc4b526fd19643bc2b3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.btns.eliminar','data' => ['class' => 'delete-registro','id' => ''.e($material->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btns.eliminar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'delete-registro','id' => ''.e($material->id).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfaf4cfa089b81cc4b526fd19643bc2b3)): ?>
<?php $attributes = $__attributesOriginalfaf4cfa089b81cc4b526fd19643bc2b3; ?>
<?php unset($__attributesOriginalfaf4cfa089b81cc4b526fd19643bc2b3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfaf4cfa089b81cc4b526fd19643bc2b3)): ?>
<?php $component = $__componentOriginalfaf4cfa089b81cc4b526fd19643bc2b3; ?>
<?php unset($__componentOriginalfaf4cfa089b81cc4b526fd19643bc2b3); ?>
<?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


            <!-- Modal visor PDF -->
            <!-- Modal PDF -->
            <?php echo $__env->make('components-vs.modals.visor-pdf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



            
            <?php echo $__env->make('obras.components-obras.form-delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/pages/highlight.js']); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/visor-pdf.js']); ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            const swalConfig = {
                title: 'Confirmación de Eliminación',
                text: 'Está a punto de eliminar un registro de forma permanente. ¿Desea continuar con esta acción irreversible?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Eliminar (Irreversible)',
                cancelButtonText: 'Mantener Registro',
            };

            // Selecciona todos los botones con la clase 'delete-material'
            const deleteButtons = document.querySelectorAll('.delete-registro');

            deleteButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    const materialId = this.getAttribute('data-id'); // Obtén el ID del material

                    Swal.fire(swalConfig).then((result) => {
                        if (result.isConfirmed) {
                            const form = document.getElementById('form-delete');
                            form.action =
                                `/materiales/${materialId}`;
                            form.submit();
                        }
                    });
                });
            });
        });


        /* Funciones para agragar rutas de imprimir informes */

        function exportPDF(obraId) {
            const form = document.getElementById('informes-form');
            form.action = `/obra/${obraId}/materiales/informes/pdf`;
            form.submit();
        }

        function exportExcel(obraId) {
            const form = document.getElementById('informes-form');
            form.action = `/obra/${obraId}/materiales/informes/excel`;
            form.submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.vertical', ['title' => 'Gastos Materiales', 'sub_title' => 'Pages', 'mode' => $mode ?? '', 'demo' => $demo ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/obras/gastos/materiales/index.blade.php ENDPATH**/ ?>