<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['href', 'title' => 'Descargar factura']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['href', 'title' => 'Descargar factura']); ?>
<?php foreach (array_filter((['href', 'title' => 'Descargar factura']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<a href="<?php echo e($href); ?>" target="_blank"
   class="inline-flex items-center justify-center w-9 h-9 rounded-full 
          bg-green-100 text-green-700 border border-green-200 
          hover:bg-green-200 hover:border-green-300 transition-all duration-200 shadow-sm"
   title="<?php echo e($title); ?>">
   <i class="mgc_download_2_line text-lg"></i>
</a>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/components/btns/descargar.blade.php ENDPATH**/ ?>