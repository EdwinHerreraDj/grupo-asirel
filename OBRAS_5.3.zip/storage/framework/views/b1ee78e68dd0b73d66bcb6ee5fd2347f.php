<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Informe de Gastos Varios</title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            color: #111111;
            background-color: #ffffff;
            margin: 40px;
        }

        /* ===== ENCABEZADO ===== */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #333333;
            padding-bottom: 12px;
            margin-bottom: 25px;
        }

        .header img {
            width: 140px;
            opacity: 0.9;
        }

        .info {
            text-align: right;
        }

        .info h1 {
            margin: 0;
            font-size: 22px;
            color: #000000;
            letter-spacing: 0.5px;
        }

        .info p {
            margin: 2px 0;
            color: #444444;
            font-size: 11.5px;
        }

        /* ===== META ===== */
        .meta {
            text-align: center;
            color: #555555;
            font-size: 11.5px;
            margin-bottom: 15px;
        }

        /* ===== TABLA ===== */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            border: 1px solid #dddddd;
        }

        th, td {
            border: 1px solid #dddddd;
            padding: 8px 10px;
            font-size: 11.5px;
        }

        th {
            background-color: #f3f4f6;
            font-weight: bold;
            text-transform: uppercase;
            color: #111111;
            font-size: 11px;
            text-align: left;
        }

        td {
            color: #222222;
        }

        tr:nth-child(even) td {
            background-color: #f9f9f9;
        }

        tfoot td {
            background-color: #f5f5f5;
            font-weight: bold;
            border-top: 2px solid #999999;
        }

        /* ===== PIE DE PÁGINA ===== */
        .footer {
            margin-top: 40px;
            text-align: center;
            font-size: 10px;
            color: #555555;
            border-top: 1px solid #cccccc;
            padding-top: 10px;
        }

        /* ===== EMPRESA ===== */
        .empresa {
            margin-top: 10px;
            color: #333333;
            font-size: 11px;
        }

        .empresa strong {
            font-size: 13px;
            color: #000000;
        }
    </style>
</head>
<body>

    
    <div class="header">
        <?php if(!empty($empresa->logo)): ?>
            <img src="<?php echo e(public_path('storage/' . $empresa->logo)); ?>" alt="Logo <?php echo e($empresa->nombre); ?>">
        <?php else: ?>
            <img src="<?php echo e(public_path('images/logo-dark.png')); ?>" alt="Logo por defecto">
        <?php endif; ?>

        <div class="info">
            <h1>Informe de Gastos Varios</h1>
            <p><strong>Obra:</strong> <?php echo e($obra->nombre); ?></p>
            <p><strong>Fecha:</strong> <?php echo e(now()->format('d/m/Y')); ?></p>
        </div>
    </div>

    
    <div class="empresa">
        <strong><?php echo e($empresa->nombre ?? 'Empresa'); ?></strong><br>
        <?php if(!empty($empresa->direccion)): ?>
            <?php echo e($empresa->direccion); ?><br>
        <?php endif; ?>
        <?php echo e($empresa->codigo_postal ?? ''); ?> <?php echo e($empresa->ciudad ?? ''); ?> <?php echo e(!empty($empresa->provincia) ? '(' . $empresa->provincia . ')' : ''); ?><br>
        <?php if(!empty($empresa->cif)): ?> CIF: <?php echo e($empresa->cif); ?> <?php endif; ?>
        <?php if(!empty($empresa->telefono)): ?> · Tel: <?php echo e($empresa->telefono); ?> <?php endif; ?>
        <?php if(!empty($empresa->email)): ?> · <?php echo e($empresa->email); ?> <?php endif; ?>
    </div>

    
    <p class="meta">
        <strong>Generado automáticamente el:</strong> <?php echo e(\Carbon\Carbon::now()->format('d/m/Y H:i')); ?>

    </p>

    
    <table>
        <thead>
            <tr>
                <th>Tipo de gasto</th>
                <th>Descripción</th>
                <th>Fecha</th>
                <th>Nº Factura</th>
                <th>Importe (€)</th>
            </tr>
        </thead>
        <tbody>
            <?php $total = 0; ?>
            <?php $__currentLoopData = $gastos_varios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $total += $gasto->importe; ?>
                <tr>
                    <td><?php echo e($gasto->tipo); ?></td>
                    <td><?php echo e($gasto->descripcion); ?></td>
                    <td>
                        <?php echo e($gasto->fecha ? \Carbon\Carbon::parse($gasto->fecha)->format('d/m/Y') : 'Sin fecha'); ?>

                    </td>
                    <td><?php echo e($gasto->numero_factura); ?></td>
                    <td><?php echo e(number_format($gasto->importe, 2, ',', '.')); ?> €</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="4" style="text-align:right;">Total general:</td>
                <td><?php echo e(number_format($total, 2, ',', '.')); ?> €</td>
            </tr>
        </tfoot>
    </table>

    
    <div class="footer">
        © <?php echo e(date('Y')); ?> <?php echo e($empresa->nombre ?? 'Geocaminos'); ?> — Documento generado automáticamente por el sistema de gestión.
    </div>

</body>
</html>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/obras/gastos/gastos-varios/pdf.blade.php ENDPATH**/ ?>