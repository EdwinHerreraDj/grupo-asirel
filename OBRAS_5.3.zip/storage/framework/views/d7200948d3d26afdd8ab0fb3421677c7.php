<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Informe General de la Obra</title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            color: #1f2937;
            background-color: #ffffff;
            margin: 0;
            padding: 0;
        }

        /* ===== ENCABEZADO ===== */
        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: #f8fafc;
            border-bottom: 3px solid #2563eb;
            padding: 12px 24px;
        }

        .empresa-info {
            color: #374151;
            line-height: 1.5;
            font-size: 11px;
        }

        .empresa-info strong {
            font-size: 15px;
            color: #1e3a8a;
            display: block;
            margin-bottom: 2px;
        }

        .logo {
            max-height: 60px;
            max-width: 180px;
        }

        /* ===== TITULOS ===== */
        h1 {
            text-align: center;
            color: #1e40af;
            font-weight: bold;
            font-size: 18px;
            margin: 20px 0 5px;
        }

        .fecha {
            text-align: center;
            color: #6b7280;
            font-size: 11px;
            margin-bottom: 15px;
        }

        /* ===== TABLA ===== */
        table {
            width: 90%;
            margin: 0 auto 25px;
            border-collapse: collapse;
            border: 1px solid #e5e7eb;
        }

        th {
            background-color: #e0f2fe;
            color: #1e3a8a;
            font-weight: bold;
            padding: 8px;
            text-align: left;
            border: 1px solid #cbd5e1;
        }

        td {
            border: 1px solid #e5e7eb;
            padding: 7px 8px;
            text-align: right;
            font-size: 12px;
        }

        td:first-child {
            text-align: left;
        }

        tr:nth-child(even) td {
            background-color: #f9fafb;
        }

        tr:hover td {
            background-color: #f1f5f9;
        }

        /* ===== BALANCE ===== */
        .balance {
            width: 90%;
            margin: 0 auto;
            font-weight: bold;
            text-align: center;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 30px;
        }

        .positive {
            background-color: #dcfce7;
            color: #166534;
        }

        .negative {
            background-color: #fee2e2;
            color: #991b1b;
        }

        /* ===== PIE ===== */
        footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: #f8fafc;
            border-top: 2px solid #2563eb;
            color: #1e3a8a;
            font-size: 10px;
            text-align: center;
            padding: 6px 0;
        }
    </style>
</head>
<body>

    
    <header>
        <div class="empresa-info">
            <strong><?php echo e($empresa->nombre ?? 'Nombre de empresa no disponible'); ?></strong>

            <?php if(!empty($empresa->direccion)): ?>
                <?php echo e($empresa->direccion); ?><br>
            <?php endif; ?>

            <?php if(!empty($empresa->codigo_postal) || !empty($empresa->ciudad) || !empty($empresa->provincia)): ?>
                <?php echo e($empresa->codigo_postal ? $empresa->codigo_postal . ' - ' : ''); ?>

                <?php echo e($empresa->ciudad ?? ''); ?>

                <?php echo e(!empty($empresa->provincia) ? ', ' . $empresa->provincia : ''); ?><br>
            <?php endif; ?>

            <?php if(!empty($empresa->cif) || !empty($empresa->telefono)): ?>
                <?php if(!empty($empresa->cif)): ?> CIF: <?php echo e($empresa->cif); ?> <?php endif; ?>
                <?php if(!empty($empresa->telefono)): ?> · Tel: <?php echo e($empresa->telefono); ?> <?php endif; ?>
                <br>
            <?php endif; ?>

            <?php if(!empty($empresa->email) || !empty($empresa->sitio_web)): ?>
                <?php if(!empty($empresa->email)): ?> Email: <?php echo e($empresa->email); ?> <?php endif; ?>
                <?php if(!empty($empresa->sitio_web)): ?> · <?php echo e($empresa->sitio_web); ?> <?php endif; ?>
            <?php endif; ?>
        </div>

        <?php if(!empty($empresa->logo)): ?>
            <img src="<?php echo e(public_path('storage/' . $empresa->logo)); ?>" alt="Logo <?php echo e($empresa->nombre); ?>" class="logo">
        <?php endif; ?>
    </header>

    
    <h1>Informe General de la Obra: <?php echo e($obra->nombre); ?></h1>
    <p class="fecha">
        <strong>Fecha de generación:</strong> <?php echo e(now()->format('d/m/Y H:i')); ?>

    </p>

    
    <table>
        <thead>
            <tr>
                <th>Tipo de Gasto</th>
                <th>Total (€)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Total Materiales</td>
                <td><?php echo e(number_format($totalMateriales, 2, ',', '.')); ?> €</td>
            </tr>
            <tr>
                <td>Total Alquileres</td>
                <td><?php echo e(number_format($totalAlquileres, 2, ',', '.')); ?> €</td>
            </tr>
            <tr>
                <td>Total Subcontratas</td>
                <td><?php echo e(number_format($totalSubcontratas, 2, ',', '.')); ?> €</td>
            </tr>
            <tr>
                <td>Total Gastos Varios</td>
                <td><?php echo e(number_format($totalGastosVarios, 2, ',', '.')); ?> €</td>
            </tr>
            <tr>
                <td>Total Gastos de Personal</td>
                <td><?php echo e(number_format($totalGanadoEmpleados, 2, ',', '.')); ?> €</td>
            </tr>
            <tr>
                <th>Total Gastos</th>
                <th><?php echo e(number_format($totalGastos, 2, ',', '.')); ?> €</th>
            </tr>
            <tr>
                <th>Total Ventas</th>
                <th><?php echo e(number_format($totalVentas, 2, ',', '.')); ?> €</th>
            </tr>
        </tbody>
    </table>

    
    <div class="balance <?php echo e($balance > 0 ? 'positive' : 'negative'); ?>">
        <strong>Balance:</strong> <?php echo e(number_format($balance, 2, ',', '.')); ?> € (<?php echo e($rentable); ?>)
    </div>

    
    <footer>
        © <?php echo e(date('Y')); ?> <?php echo e($empresa->nombre ?? 'Empresa'); ?> — Documento generado automáticamente por el sistema de gestión.
    </footer>

</body>
</html>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/obras/pdf-general.blade.php ENDPATH**/ ?>