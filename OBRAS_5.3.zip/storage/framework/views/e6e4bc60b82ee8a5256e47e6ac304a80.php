<?php $__env->startSection('content'); ?>
<div class="card">
	<div class="card-header">
		<div class="flex justify-between items-center">
			<h5 class="card-title">
				All Icons
			</h5>

			<a href="https://www.mingcute.com/" target="_blank" class="btn-code">
				<span class="me-2">Documentaion</span>
				<i class="mgc_link_2_line text-sm"></i>
			</a>
		</div>
	</div>
	<div class="p-6">
		<div class="grid lg:grid-cols-5 md:grid-cols-3 gap-6 icons-list-demo" id="icons"></div>
	</div>
</div>
<!-- end card -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/pages/icons-mingcute.js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vertical', ['title' => 'Mingcute', 'sub_title' => 'Icons', 'mode' => $mode ?? '', 'demo' => $demo ?? ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/icons/mingcute.blade.php ENDPATH**/ ?>