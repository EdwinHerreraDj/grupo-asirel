
            <?php if(session('success')): ?>
                <script>
                    const notyf = new Notyf({
                        duration: 4000,
                        dismissible: true,
                        position: {
                            x: 'right',
                            y: 'top',
                        },
                    });

                    // Mostrar mensaje de éxito
                    notyf.success('<?php echo e(session('success')); ?>');
                </script>
            <?php endif; ?><?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/notifications/notyf.blade.php ENDPATH**/ ?>