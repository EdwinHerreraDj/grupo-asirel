<div class="mb-10">
   
    
    <!--[if BLOCK]><![endif]--><?php if($showModal): ?>
        <div
            class="relative p-5 border border-blue-200 rounded-xl shadow-md 
            bg-white dark:bg-gray-800 dark:border-blue-900/40 
            animate-fadeIn overflow-hidden transition-all duration-300 mb-5 w-full mt-5">

            
            <div class="absolute left-0 top-0 h-full w-1 bg-blue-500/80 rounded-l-xl"></div>

            
            <div class="flex items-center gap-3 mb-4">
                <div
                    class="flex items-center justify-center w-9 h-9 rounded-lg 
            bg-blue-100 text-blue-600 dark:bg-blue-800 dark:text-blue-300">
                    <i class="mgc_black_board_2_line text-xl"></i>
                </div>
                <div>
                    <h3 class="text-base font-semibold text-gray-800 dark:text-gray-100">Crear nueva categoría</h3>
                    <p class="text-xs text-gray-500 dark:text-gray-400">Clasifica y organiza los gastos de tu empresa
                    </p>
                </div>
            </div>

            
            <form wire:submit.prevent="guardar" class="space-y-4">

                
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">
                        Nombre <span class="text-red-500">*</span>
                    </label>
                    <input type="text" wire:model.defer="nombre"
                        placeholder="Ejemplo: Transporte, Materiales, Servicios, etc."
                        class="w-full px-3.5 py-2 border border-gray-300 rounded-md text-gray-800 dark:text-white 
                dark:bg-gray-800 dark:border-gray-600 placeholder-gray-400
                focus:ring-1 focus:ring-blue-500 focus:border-blue-500 
                transition-all duration-200 text-sm" />

                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-600 text-xs font-medium mt-2 dark:text-red-400 flex items-center gap-1.5">
                            <i class="mgc_warning_line text-sm"></i> <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                </div>

                
                <div>
                    <label class="block text-sm font-medium text-gray-700 dark:text-gray-300">Descripción</label>
                    <textarea wire:model.defer="descripcion" placeholder="Describe brevemente el propósito de esta categoría..."
                        rows="3"
                        class="w-full px-3.5 py-2 border border-gray-300 rounded-md text-gray-800 dark:text-white 
                dark:bg-gray-800 dark:border-gray-600 placeholder-gray-400
                focus:ring-1 focus:ring-blue-500 focus:border-blue-500 
                transition-all duration-200 text-sm"></textarea>
                </div>

                
                <div class="pt-2 flex flex-wrap justify-end gap-2">
                    <button type="button" wire:click="$set('showModal', false)"
                        class="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-md
                border border-gray-300 bg-white text-gray-700 text-sm font-medium
                hover:bg-gray-50 active:scale-[0.98]
                dark:bg-gray-800 dark:text-gray-300 dark:border-gray-600
                dark:hover:bg-gray-700 focus:outline-none focus:ring-1 focus:ring-gray-400 
                transition-all duration-200">
                        <i class="mgc_close_fill text-base"></i>
                        Cancelar
                    </button>

                    <button type="submit"
                        class="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-md
                bg-blue-600 text-white text-sm font-medium
                hover:bg-blue-700 active:scale-[0.98]
                focus:outline-none focus:ring-2 focus:ring-blue-300 
                transition-all duration-200">
                        <i class="mgc_check_fill text-base"></i>
                        Guardar
                    </button>
                </div>
            </form>
        </div>


        
        <div
            class="relative p-5 border border-blue-200 rounded-xl shadow-md 
    bg-white dark:bg-gray-800 dark:border-blue-900/40 
    animate-fadeIn overflow-hidden transition-all duration-300 mt-8 w-full">

            
            <div class="absolute left-0 top-0 h-full w-1 bg-blue-500/80 rounded-l-xl"></div>

            
            <div class="flex items-center gap-3 mb-4">
                <div
                    class="flex items-center justify-center w-9 h-9 rounded-lg 
            bg-blue-100 text-blue-600 dark:bg-blue-800 dark:text-blue-300">
                    <i class="mgc_list_check_2_line text-xl"></i>
                </div>
                <div>
                    <h3 class="text-base font-semibold text-gray-800 dark:text-gray-100">Categorías registradas</h3>
                    <p class="text-xs text-gray-500 dark:text-gray-400">Consulta y gestiona tus categorías de gasto</p>
                </div>
            </div>

            
            <div class="overflow-x-auto rounded-lg border border-gray-200 dark:border-gray-700">
                <table class="min-w-full text-sm divide-y divide-gray-200 dark:divide-gray-700">
                    <thead
                        class="bg-blue-50 dark:bg-blue-900/40 text-gray-700 dark:text-gray-200 text-xs uppercase tracking-wider">
                        <tr>
                            <th class="px-4 py-3 text-left font-semibold">Nombre</th>
                            <th class="px-4 py-3 text-left font-semibold">Descripción</th>
                            <th class="px-4 py-3 text-center font-semibold w-24">Acciones</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-blue-50/50 dark:hover:bg-blue-900/20 transition-all duration-150">
                                <td class="px-4 py-3 font-medium text-gray-800 dark:text-gray-100">
                                    <?php echo e($categoria->nombre); ?>

                                </td>
                                <td class="px-4 py-3 text-gray-600 dark:text-gray-300">
                                    <?php echo e($categoria->descripcion ?? '—'); ?>

                                </td>
                                <td class="px-4 py-3 text-center">
                                    <button wire:click="eliminar(<?php echo e($categoria->id); ?>)"
                                        class="inline-flex items-center justify-center w-8 h-8 rounded-md
                                text-red-600 hover:text-white hover:bg-red-600
                                dark:text-red-400 dark:hover:text-white dark:hover:bg-red-500
                                transition-all duration-150">
                                        <i class="mgc_delete_2_line text-lg"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" class="text-center py-6 text-gray-500 dark:text-gray-400 italic">
                                    No hay categorías registradas.
                                </td>
                            </tr>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>
        </div>


    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/livewire/empresa/gastos/categorias-gasto-empresa.blade.php ENDPATH**/ ?>