<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            color: #111827;
            margin: 20px;
        }

        /* ==== ENCABEZADO EMPRESA ==== */
        .empresa {
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #93c5fd;
        }
        .empresa strong {
            font-size: 14px;
            color: #1d4ed8;
        }
        .empresa p {
            margin: 2px 0;
            color: #374151;
            font-size: 11px;
        }

        /* ==== TITULO ==== */
        h2 {
            text-align: center;
            font-weight: bold;
            color: #1d4ed8;
            margin-bottom: 4px;
        }
        .meta {
            text-align: center;
            color: #4b5563;
            font-size: 11px;
            margin-bottom: 10px;
        }

        /* ==== TABLA ==== */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            border: 1px solid #e5e7eb;
            padding: 6px 8px;
            text-align: right;
            vertical-align: middle;
        }
        th {
            background-color: #e0f2fe;
            color: #1e3a8a;
            font-weight: bold;
        }
        td:first-child, th:first-child {
            text-align: left;
        }
        tr:nth-child(even) td {
            background-color: #f9fafb;
        }

        /* ==== TOTALES ==== */
        tfoot td {
            font-weight: bold;
            background-color: #eff6ff;
            border-top: 2px solid #93c5fd;
        }
    </style>
</head>
<body>

    
    <?php if(isset($empresa)): ?>
        <div class="empresa">
            <strong><?php echo e($empresa->nombre ?? 'Empresa'); ?></strong><br>
            <?php if(!empty($empresa->direccion)): ?>
                <p><?php echo e($empresa->direccion); ?></p>
            <?php endif; ?>
            <?php if(!empty($empresa->codigo_postal) || !empty($empresa->ciudad)): ?>
                <p><?php echo e($empresa->codigo_postal ?? ''); ?> <?php echo e($empresa->ciudad ?? ''); ?> <?php echo e(!empty($empresa->provincia) ? '(' . $empresa->provincia . ')' : ''); ?></p>
            <?php endif; ?>
            <p>
                <?php if(!empty($empresa->cif)): ?> CIF: <?php echo e($empresa->cif); ?> <?php endif; ?>
                <?php if(!empty($empresa->telefono)): ?> · Tel: <?php echo e($empresa->telefono); ?> <?php endif; ?>
            </p>
            <?php if(!empty($empresa->email) || !empty($empresa->sitio_web)): ?>
                <p>
                    <?php if(!empty($empresa->email)): ?> <?php echo e($empresa->email); ?> <?php endif; ?>
                    <?php if(!empty($empresa->sitio_web)): ?> · <?php echo e($empresa->sitio_web); ?> <?php endif; ?>
                </p>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    
    <h2>Informe de Facturación Total</h2>
    <p class="meta">
        <strong>Estado:</strong> <?php echo e($filtros['estado'] !== 'todas' ? ucfirst($filtros['estado']) : 'Todos'); ?> |
        <strong>Generado:</strong> <?php echo e(now()->format('d/m/Y H:i')); ?>

    </p>
    <?php if($filtros['fechaInicio'] && $filtros['fechaFin']): ?>
        <p class="meta">
            <strong>Periodo:</strong> 
            <?php echo e(\Carbon\Carbon::parse($filtros['fechaInicio'])->format('d/m/Y')); ?> - 
            <?php echo e(\Carbon\Carbon::parse($filtros['fechaFin'])->format('d/m/Y')); ?>

        </p>
    <?php endif; ?>

    
    <table>
        <thead>
            <tr>
                <th>Obra</th>
                <th>Estado</th>
                <th>Nº Ventas</th>
                <th>Total Facturado (€)</th>
                <th>Primera Venta</th>
                <th>Última Venta</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $resultado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($r['nombre']); ?></td>
                    <td><?php echo e(ucfirst($r['estado'])); ?></td>
                    <td><?php echo e($r['num_ventas']); ?></td>
                    <td><?php echo e(number_format($r['total'], 2, ',', '.')); ?></td>
                    <td><?php echo e($r['primera']); ?></td>
                    <td><?php echo e($r['ultima']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" style="text-align:right;">TOTAL GLOBAL</td>
                <td><?php echo e(number_format($totalGlobal, 2, ',', '.')); ?></td>
                <td colspan="2"></td>
            </tr>
        </tfoot>
    </table>

</body>
</html>
<?php /**PATH C:\Users\USER\Documents\ALMINARES\APPS WEBS\01-OBRAS-BASE\OBRA\resources\views/exports/informes/facturacion-total.blade.php ENDPATH**/ ?>