<div>

    {{-- ======================
        ACCIONES SUPERIORES
    ======================= --}}
    
    <div class="flex flex-wrap items-center gap-3 mb-7">

        <x-btns.regresar href="{{ route('empresa.index') }}">
            Regresar
        </x-btns.regresar>

        <x-btns.agregar wire:click="nuevaFactura">
            Nueva factura
        </x-btns.agregar>

        <a href="{{ route('empresa.facturas-series') }}"
            class="inline-flex items-center gap-2 px-4 py-2 rounded-full font-medium shadow-sm
                   bg-blue-500/20 text-blue-700 border border-blue-500/30
                   hover:bg-blue-600 hover:text-white transition-all duration-300">
            <i class="mgc_paper_line text-lg"></i>
            Series 
        </a>

        

    </div>

    <h2 class="text-xl font-semibold text-white bg-primary p-4 rounded-lg shadow mb-4">
        Facturas de ventas {{$showFormulario}}
    </h2>

    {{-- ======================
        FILTROS
    ======================= --}}
    <x-tablas.filters>
        <div class="flex gap-4">
            <input wire:model.defer="search" class="rounded-lg border-gray-300" placeholder="Buscar factura...">

            <select wire:model.defer="estado" class="rounded-lg border-gray-300">
                <option value="">Todos los estados</option>
                <option value="borrador">Borrador</option>
                <option value="emitida">Emitida</option>
                <option value="enviada">Enviada</option>
                <option value="pagada">Pagada</option>
                <option value="anulada">Anulada</option>
            </select>

            <button wire:click="$refresh" class="btn">
                Filtrar
            </button>
        </div>
    </x-tablas.filters>

    {{-- ======================
        TABLA
    ======================= --}}
    <x-tablas.table>

        {{-- CABECERA --}}
        <x-slot name="columns">
            <th class="px-4 py-2 text-left">Factura</th>
            <th class="px-4 py-2 text-left">Origen</th>
            <th class="px-4 py-2 text-left">Cliente</th>
            <th class="px-4 py-2 text-left">Obra</th>
            <th class="px-4 py-2 text-left">Fecha emisión</th>
            <th class="px-4 py-2 text-left">Certificación</th>
            <th class="px-4 py-2 text-right">Total</th>
            <th class="px-4 py-2 text-left">Estado</th>
            <th class="px-4 py-2 text-center">PDF</th>
            <th class="px-4 py-2 text-right">Acciones</th>
        </x-slot>

        {{-- FILAS --}}
        <x-slot name="rows">
            @forelse ($facturas as $factura)
                <tr class="hover:bg-gray-50 transition">

                    {{-- FACTURA --}}
                    <td class="px-6 py-4 font-medium">
                        {{ $factura->numero_factura ?? '—' }}
                    </td>

                    {{-- ORIGEN --}}
                    <td class="px-6 py-4">
                        <span
                            class="px-2 py-1 rounded-full text-xs font-semibold
                            {{ $factura->origen === 'manual' ? 'bg-indigo-100 text-indigo-700' : 'bg-purple-100 text-purple-700' }}">
                            {{ ucfirst($factura->origen) }}
                        </span>
                    </td>

                    {{-- CLIENTE --}}
                    <td class="px-6 py-4 max-w-[220px]">
                        <span class="block truncate">
                            {{ $factura->cliente?->nombre ?? '—' }}
                        </span>
                    </td>

                    {{-- OBRA --}}
                    <td class="px-6 py-4 max-w-[220px]">
                        <span class="block truncate">
                            {{ $factura->obra?->nombre ?? '—' }}
                        </span>
                    </td>

                    {{-- FECHA --}}
                    <td class="px-6 py-4">
                        {{ optional($factura->fecha_emision)->format('d/m/Y') }}
                    </td>

                    {{-- CERTIFICACIÓN --}}
                    <td class="px-6 py-4">
                        {{ $factura->codigo_certificacion ?? '—' }}
                    </td>

                    {{-- TOTAL --}}
                    <td class="px-6 py-4 text-right font-semibold">
                        {{ number_format($factura->total, 2, ',', '.') }} €
                    </td>

                    {{-- ESTADO --}}
                    <td class="px-6 py-4">
                        <span
                            class="px-2 py-1 rounded-full text-xs font-semibold
                            @class([
                                'bg-gray-100 text-gray-700' => $factura->estado === 'borrador',
                                'bg-blue-100 text-blue-700' => $factura->estado === 'emitida',
                                'bg-yellow-100 text-yellow-700' => $factura->estado === 'enviada',
                                'bg-green-100 text-green-700' => $factura->estado === 'pagada',
                                'bg-red-100 text-red-700' => $factura->estado === 'anulada',
                            ])">
                            {{ ucfirst($factura->estado) }}
                        </span>
                    </td>

                    {{-- PDF --}}
                    <td class="px-6 py-4 text-center">
                        @if ($factura->pdf_url)
                            <a href="{{ asset('storage/' . $factura->pdf_url) }}" target="_blank"
                                class="text-red-600 hover:text-red-800">
                                <i class="mgc_file_pdf_line text-xl"></i>
                            </a>
                        @else
                            <span class="text-gray-300">—</span>
                        @endif
                    </td>

                    {{-- ACCIONES --}}
                    <td class="px-6 py-4 text-right">
                        <div x-data="{ open: false }" class="relative inline-block">

                            <button @click="open = !open" class="p-2 rounded-lg hover:bg-gray-100">
                                <i class="mgc_more_2_line text-lg"></i>
                            </button>

                            <div x-show="open" @click.away="open = false"
                                class="absolute right-0 z-50 mt-2 w-44 bg-white border rounded-xl shadow-lg">

                                <button wire:click="editarFactura({{ $factura->id }})"
                                    class="w-full text-left px-4 py-2 hover:bg-gray-100">
                                    Editar
                                </button>

                                @if ($factura->estado === 'borrador')
                                    <button wire:click="confirmarEmision({{ $factura->id }})"
                                        class="w-full text-left px-4 py-2 text-emerald-600 hover:bg-emerald-50">
                                        Emitir
                                    </button>
                                @endif

                            </div>
                        </div>
                    </td>

                </tr>
            @empty
                <tr>
                    <td colspan="10" class="px-6 py-6 text-center text-gray-500">
                        No hay facturas de venta registradas.
                    </td>
                </tr>
            @endforelse
        </x-slot>

        <x-slot name="pagination">
            {{ $facturas->links() }}
        </x-slot>

    </x-tablas.table>

    {{-- ======================
        MODAL FORMULARIO
    ======================= --}}

    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4   {{ $showFormulario === true ? '' : 'hidden' }}">
        <div class="bg-white w-full max-w-3xl rounded-2xl shadow border max-h-[92vh] flex flex-col">

            <div class="flex items-center p-5 border-b">
                <h3 class="text-xl font-semibold">
                    {{ $facturaId ? 'Editar factura' : 'Nueva factura' }}
                </h3>
                <button wire:click="cerrarModalForm" class="ml-auto text-3xl">&times;</button>
            </div>

            <div class="p-6 overflow-y-auto">
                <livewire:empresa.facturas-ventas.formulario :factura-id="$facturaId"
                    wire:key="formulario-factura-{{ $facturaId ?? 'new' }}" />
            </div>

        </div>
    </div>


</div>
