@vite(['resources/scss/app.scss', 'resources/scss/icons.scss'])
@vite(['resources/js/head.js', 'resources/js/config.js'])
